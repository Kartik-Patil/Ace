//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-D7Yke8xV.js
var manifest = {
	"262f528896f581df4ad92ee8011e704e16ec47a2b17f4cdfd16959e3f2159c63": {
		functionName: "sendEnquiryServerFn_createServerFn_handler",
		importer: () => import("./_ssr/mail-B62zDYty.mjs")
	},
	"a4a06ffed0c1ec526f7a848ed7624d0fbea05949c8868155798d82dbb6641c52": {
		functionName: "sendOtpServerFn_createServerFn_handler",
		importer: () => import("./_ssr/mail-B62zDYty.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
