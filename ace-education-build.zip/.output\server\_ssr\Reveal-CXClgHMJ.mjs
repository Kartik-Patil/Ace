import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { f as cn } from "./ContactSection-BXmyUUuK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Reveal-CXClgHMJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Returns a ref and a boolean `inView`.
* Once the element enters the viewport it stays `true` (fires once).
*/
function useInView(options) {
	const ref = (0, import_react.useRef)(null);
	const [inView, setInView] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const observer = new IntersectionObserver(([entry]) => {
			if (entry?.isIntersecting) {
				setInView(true);
				observer.disconnect();
			}
		}, {
			threshold: .12,
			rootMargin: "0px 0px -48px 0px",
			...options
		});
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	return {
		ref,
		inView
	};
}
function Reveal({ children, variant = "fade-up", delay = 0, duration = 600, className, as: Tag = "div", threshold }) {
	const { ref, inView } = useInView({ threshold: threshold ?? .12 });
	const style = {
		transitionDuration: `${duration}ms`,
		transitionDelay: inView ? `${delay}ms` : "0ms"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
		ref,
		className: cn("reveal", `reveal-${variant}`, inView && "reveal-visible", className),
		style,
		children
	});
}
//#endregion
export { useInView as n, Reveal as t };
