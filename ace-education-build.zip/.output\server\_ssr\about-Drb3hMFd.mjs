import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { R as ArrowRight, o as Sparkles, r as Trophy } from "../_libs/lucide-react.mjs";
import { l as SectionHeading, r as ContactSection, t as AceWord } from "./ContactSection-BXmyUUuK.mjs";
import { t as study_illustration_default } from "./study-illustration-CcH1CutX.mjs";
import { t as Reveal } from "./Reveal-CXClgHMJ.mjs";
import { n as RollingNumber, t as ExamReadySection } from "./ExamReadySection-Daf8LaMa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-Drb3hMFd.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-navy-pattern text-navy-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace grid items-center gap-10 py-16 md:py-24 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fade-up",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "inline-flex items-center gap-2 rounded-full bg-gold px-4 py-1.5 text-xs font-bold text-gold-foreground uppercase tracking-widest",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
									className: "size-3.5",
									"aria-hidden": true
								}),
								" About Us – ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }),
								" Education, Hubballi"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-5 text-5xl font-semibold leading-[1.08] md:text-6xl",
							children: ["From Concepts ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "italic text-gold",
								children: "to Confidence"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 max-w-xl text-lg leading-relaxed opacity-90",
							children: [
								"At ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }),
								" Education, Hubballi, we believe that every student has the potential to excel when guided with the right knowledge, mentorship and learning environment."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap items-center gap-3 text-xs font-semibold uppercase tracking-wider text-gold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-gold/40 px-3.5 py-1.5 bg-navy/60",
									children: "Established in 2022"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-gold/40 px-3.5 py-1.5 bg-navy/60",
									children: "500+ Students"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-gold/40 px-3.5 py-1.5 bg-navy/60",
									children: "Academic Excellence & Beyond Classroom Learning"
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative fade-up [animation-delay:150ms]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: study_illustration_default,
						alt: "ACE Education students learning together",
						width: 1280,
						height: 960,
						className: "rounded-3xl border-4 border-gold/70 shadow-lift object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute -bottom-6 left-6 rounded-2xl bg-card p-4 text-card-foreground shadow-lift",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-bold text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RollingNumber, { value: "500+" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "students guided since 2022"
						})]
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b bg-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace grid grid-cols-1 gap-6 py-8 sm:grid-cols-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						variant: "fade-up",
						delay: 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-bold text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RollingNumber, { value: "2022" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-semibold text-muted-foreground",
							children: "Established"
						})] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						variant: "fade-up",
						delay: 80,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-bold text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RollingNumber, { value: "500+" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-semibold text-muted-foreground",
							children: "Students Guided"
						})] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						variant: "fade-up",
						delay: 160,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-bold text-primary",
							children: "Classes 8, 9 & 10"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-semibold text-muted-foreground",
							children: "Foundation & Board Support"
						})] })
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-ace py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 lg:grid-cols-2 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					variant: "slide-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Our Journey",
							title: "Dedicated Learning Centre in Hubballi"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 text-base leading-relaxed text-muted-foreground",
							children: [
								"Established in 2022, ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
								" has grown into a dedicated learning centre, having guided and supported 500+ students on their academic journey. We are committed to nurturing young minds through quality education, personalised mentoring and a strong foundation in essential academic concepts."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-base leading-relaxed text-muted-foreground",
							children: "We specialise in Foundation Programmes and Board Examination Support for Classes 8, 9 and 10, with a focus on building conceptual clarity, strengthening analytical abilities and developing problem-solving skills."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					variant: "slide-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group rounded-2xl border-2 border-sky-border/40 bg-card p-7 transition duration-300 hover:-translate-y-1 hover:border-sky-border hover:shadow-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-11 place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
											className: "size-5 text-gold",
											"aria-hidden": true
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-sky px-3 py-1 text-xs font-bold uppercase tracking-wider text-primary border border-sky-border/30",
										children: "Interactive Learning"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 font-display text-xl font-bold text-primary",
									children: "Beyond Textbooks & Classroom Teaching"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted-foreground",
									children: [
										"At ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
										", education goes beyond textbooks and classroom teaching. We integrate interactive teaching methodologies, experiment-based learning, practical activities and skill development to make learning meaningful, engaging and effective."
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group rounded-2xl border-2 border-sky-border/40 bg-sky/70 p-7 transition duration-300 hover:-translate-y-1 hover:border-sky-border hover:shadow-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-11 place-items-center rounded-xl bg-gold text-gold-foreground shadow-sm",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, {
											className: "size-5",
											"aria-hidden": true
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-gold px-3 py-1 text-xs font-bold uppercase tracking-wider text-gold-foreground",
										children: "Future Readiness"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 font-display text-xl font-bold text-primary",
									children: "Preparing for Future Academic Challenges"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted-foreground",
									children: "Our approach focuses not just on helping students score better marks but also on developing confidence, discipline, critical thinking and independent learning abilities that prepare them for future academic challenges."
								})
							]
						})]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExamReadySection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-ace py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				variant: "fade-up",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Guiding Principles",
					title: "Our Vision & Mission"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-8 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					variant: "slide-left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-3xl bg-navy-pattern p-8 text-navy-foreground border-2 border-gold/40 shadow-lift flex flex-col justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-[0.2em] text-gold",
								children: "Our Vision"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-2xl font-bold",
								children: "Nurturing Confident Learners"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-base leading-relaxed opacity-90",
								children: "To nurture confident, knowledgeable and independent learners by creating an enriching academic environment that inspires curiosity, builds competence and prepares students for a successful future."
							})
						] })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					variant: "slide-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-3xl border-2 border-sky-border bg-sky p-8 shadow-lift flex flex-col justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-[0.2em] text-sky-border",
								children: "Our Mission"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-2xl font-bold text-primary",
								children: "Empowering Academic Excellence"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-base leading-relaxed text-muted-foreground",
								children: "To deliver quality education through innovative teaching, strong conceptual foundations, individual attention and holistic skill development, empowering every student to achieve their academic goals and excel beyond the classroom."
							})
						] })
					})
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-navy-pattern py-16 text-navy-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				variant: "zoom-in",
				className: "container-ace flex flex-col items-center gap-4 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-bold uppercase tracking-[0.25em] text-gold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }), " Education"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-3xl font-semibold md:text-5xl",
						children: ["Your Ambition, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "italic text-gold",
							children: "Our Foundation."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base font-bold uppercase tracking-[0.2em] text-gold-foreground bg-gold px-6 py-2 rounded-full mt-2",
						children: "Learn. Lead. Excel."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap justify-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/courses",
							className: "inline-flex items-center gap-2 rounded-full bg-gold px-7 py-3.5 font-bold text-gold-foreground transition hover:-translate-y-0.5",
							children: ["Explore our programmes ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
								className: "size-4",
								"aria-hidden": true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#enquire",
							className: "inline-flex items-center gap-2 rounded-full border-2 border-navy-foreground/40 px-7 py-3.5 font-bold transition hover:border-gold hover:text-gold",
							children: "Enquire Now"
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactSection, {})
	] });
}
//#endregion
export { AboutPage as component };
