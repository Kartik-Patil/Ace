import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react } from "./@radix-ui/react-accordion+[...].mjs";
//#region node_modules/input-otp/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var kt = Object.defineProperty;
var xt = Object.defineProperties;
var Gt = Object.getOwnPropertyDescriptors;
var U = Object.getOwnPropertySymbols;
var ht = Object.prototype.hasOwnProperty;
var St = Object.prototype.propertyIsEnumerable;
var Et = (o, r, t) => r in o ? kt(o, r, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: t
}) : o[r] = t;
var bt = (o, r) => {
	for (var t in r || (r = {})) ht.call(r, t) && Et(o, t, r[t]);
	if (U) for (var t of U(r)) St.call(r, t) && Et(o, t, r[t]);
	return o;
};
var Pt = (o, r) => xt(o, Gt(r));
var wt = (o, r) => {
	var t = {};
	for (var u in o) ht.call(o, u) && r.indexOf(u) < 0 && (t[u] = o[u]);
	if (o != null && U) for (var u of U(o)) r.indexOf(u) < 0 && St.call(o, u) && (t[u] = o[u]);
	return t;
};
function _t(o) {
	return [
		setTimeout(o, 0),
		setTimeout(o, 10),
		setTimeout(o, 50)
	];
}
function Tt(o) {
	let r = import_react.useRef();
	return import_react.useEffect(() => {
		r.current = o;
	}), r.current;
}
var Ot = 18;
var nt = 40;
var Lt = `${nt}px`;
function Ct(o) {
	let r = o.getBoundingClientRect().right, t = o;
	for (; t;) {
		if (getComputedStyle(t).overflowX !== "visible") return t.getBoundingClientRect().left + t.clientLeft + t.clientWidth - r;
		t = t.parentElement;
	}
	return document.documentElement.clientWidth - r;
}
var jt = [
	"[data-lastpass-icon-root]",
	"com-1password-button",
	"[data-dashlanecreated]",
	"[style$=\"2147483647 !important;\"]"
].join(",");
function Mt({ containerRef: o, inputRef: r, pushPasswordManagerStrategy: t, isFocused: u }) {
	let [w, T] = import_react.useState(!1), [x, M] = import_react.useState(!1), [V, I] = import_react.useState(!1), q = import_react.useMemo(() => t === "none" ? !1 : (t === "increase-width" || t === "experimental-no-flickering") && w && x, [
		w,
		x,
		t
	]), y = import_react.useCallback(() => {
		let m = o.current, S = r.current;
		if (!m || !S || V || t === "none") return;
		let R = m, i = R.getBoundingClientRect().left + R.offsetWidth, G = R.getBoundingClientRect().top + R.offsetHeight / 2, ot = i - Ot, X = G;
		document.querySelectorAll(jt).length === 0 && document.elementFromPoint(ot, X) === m || (M(Ct(m) >= nt), T(!0), I(!0));
	}, [
		o,
		r,
		V,
		t
	]);
	return import_react.useEffect(() => {
		let m = o.current;
		if (!m || t === "none") return;
		function S() {
			M(Ct(m) >= nt);
		}
		S();
		let R = setInterval(S, 1e3);
		return () => {
			clearInterval(R);
		};
	}, [o, t]), import_react.useEffect(() => {
		let m = u || document.activeElement === r.current;
		if (t === "none" || !m) return;
		let S = setTimeout(y, 0), R = setTimeout(y, 2e3), i = setTimeout(y, 5e3), G = setTimeout(() => {
			I(!0);
		}, 6e3);
		return () => {
			clearTimeout(S), clearTimeout(R), clearTimeout(i), clearTimeout(G);
		};
	}, [
		r,
		u,
		t,
		y
	]), {
		hasPWMBadge: w,
		willPushPWMBadge: q,
		PWM_BADGE_SPACE_WIDTH: Lt
	};
}
var Nt = import_react.createContext({});
var $t = import_react.forwardRef((ot, G) => {
	var X = ot, { value: o, onChange: r, maxLength: t, textAlign: u = "left", pattern: w, placeholder: T, inputMode: x = "numeric", onComplete: M, pushPasswordManagerStrategy: V = "increase-width", pasteTransformer: I, containerClassName: q, noScriptCSSFallback: y = Ft, nonce: m, render: S, children: R } = X, i = wt(X, [
		"value",
		"onChange",
		"maxLength",
		"textAlign",
		"pattern",
		"placeholder",
		"inputMode",
		"onComplete",
		"pushPasswordManagerStrategy",
		"pasteTransformer",
		"containerClassName",
		"noScriptCSSFallback",
		"nonce",
		"render",
		"children"
	]);
	var z, ft, mt, pt, Rt;
	let [rt, at] = import_react.useState(typeof i.defaultValue == "string" ? i.defaultValue : ""), l = o != null ? o : rt, D = Tt(l), O = import_react.useCallback((a) => {
		r?.(a), at(a);
	}, [r]), p = import_react.useMemo(() => w ? typeof w == "string" ? new RegExp(w) : w : null, [w]), d = import_react.useRef(null), K = import_react.useRef(null), J = import_react.useRef({
		value: l,
		onChange: O,
		isIOS: typeof window != "undefined" && ((ft = (z = window == null ? void 0 : window.CSS) == null ? void 0 : z.supports) == null ? void 0 : ft.call(z, "-webkit-touch-callout", "none"))
	}), Y = import_react.useRef({ prev: [
		(mt = d.current) == null ? void 0 : mt.selectionStart,
		(pt = d.current) == null ? void 0 : pt.selectionEnd,
		(Rt = d.current) == null ? void 0 : Rt.selectionDirection
	] });
	import_react.useImperativeHandle(G, () => d.current, []), import_react.useEffect(() => {
		let a = d.current, n = K.current;
		if (!a || !n) return;
		J.current.value !== a.value && J.current.onChange(a.value), Y.current.prev = [
			a.selectionStart,
			a.selectionEnd,
			a.selectionDirection
		];
		function c() {
			if (document.activeElement !== a) {
				j(null), N(null);
				return;
			}
			let s = a.selectionStart, P = a.selectionEnd, $ = a.selectionDirection, v = a.maxLength, B = a.value, _ = Y.current.prev, g = -1, E = -1, C;
			if (B.length !== 0 && s !== null && P !== null) {
				let Bt = s === P, Wt = s === B.length && B.length < v;
				if (Bt && !Wt) {
					let W = s;
					if (W === 0) g = 0, E = 1, C = "forward";
					else if (W === v) g = W - 1, E = W, C = "backward";
					else if (v > 1 && B.length > 1) {
						let et = 0;
						if (_[0] !== null && _[1] !== null) {
							C = W < _[1] ? "backward" : "forward";
							let At = _[0] === _[1] && _[0] < v;
							C === "backward" && !At && (et = -1);
						}
						g = et + W, E = et + W + 1;
					}
				}
				g !== -1 && E !== -1 && g !== E && a.setSelectionRange(g, E, C);
			}
			let vt = g !== -1 ? g : s, gt = E !== -1 ? E : P, Ht = C != null ? C : $;
			j(vt), N(gt), Y.current.prev = [
				vt,
				gt,
				Ht
			];
		}
		if (document.addEventListener("selectionchange", c, { capture: !0 }), c(), document.activeElement === a && Q(!0), !document.getElementById("input-otp-style")) {
			let s = document.createElement("style");
			if (s.id = "input-otp-style", m && s.setAttribute("nonce", m), document.head.appendChild(s), s.sheet) {
				let P = "background: transparent !important; color: transparent !important; border-color: transparent !important; opacity: 0 !important; box-shadow: none !important; -webkit-box-shadow: none !important; -webkit-text-fill-color: transparent !important;";
				F(s.sheet, "[data-input-otp]::selection { background: transparent !important; color: transparent !important; }"), F(s.sheet, `[data-input-otp]:autofill { ${P} }`), F(s.sheet, `[data-input-otp]:-webkit-autofill { ${P} }`), F(s.sheet, "@supports (-webkit-touch-callout: none) { [data-input-otp] { letter-spacing: -.6em !important; font-weight: 100 !important; font-stretch: ultra-condensed; font-optical-sizing: none !important; left: -1px !important; right: 1px !important; } }"), F(s.sheet, "[data-input-otp] + * { pointer-events: all !important; }");
			}
		}
		let b = () => {
			n && n.style.setProperty("--root-height", `${a.clientHeight}px`);
		};
		b();
		let f = typeof ResizeObserver == "undefined" ? null : new ResizeObserver(b);
		return f?.observe(a), () => {
			document.removeEventListener("selectionchange", c, { capture: !0 }), f?.disconnect();
		};
	}, []);
	let [ct, it] = import_react.useState(!1), [L, Q] = import_react.useState(!1), [H, j] = import_react.useState(null), [A, N] = import_react.useState(null);
	import_react.useEffect(() => {
		let a = _t(() => {
			var f, s, P, $;
			(f = d.current) == null || f.dispatchEvent(new Event("input"));
			let n = (s = d.current) == null ? void 0 : s.selectionStart, c = (P = d.current) == null ? void 0 : P.selectionEnd, b = ($ = d.current) == null ? void 0 : $.selectionDirection;
			n !== null && c !== null && (j(n), N(c), Y.current.prev = [
				n,
				c,
				b
			]);
		});
		return () => {
			a.forEach((n) => clearTimeout(n));
		};
	}, [l, L]), import_react.useEffect(() => {
		D !== void 0 && l !== D && D.length < t && l.length === t && M?.(l);
	}, [
		t,
		M,
		D,
		l
	]);
	let k = Mt({
		containerRef: K,
		inputRef: d,
		pushPasswordManagerStrategy: V,
		isFocused: L
	}), st = import_react.useCallback((a) => {
		let n = a.currentTarget.value.slice(0, t);
		if (n.length > 0 && p && !p.test(n)) {
			a.preventDefault();
			return;
		}
		typeof D == "string" && n.length < D.length && document.dispatchEvent(new Event("selectionchange")), O(n);
	}, [
		t,
		O,
		D,
		p
	]), lt = import_react.useCallback(() => {
		var a;
		if (d.current) {
			let n = Math.min(d.current.value.length, t - 1), c = d.current.value.length;
			(a = d.current) == null || a.setSelectionRange(n, c), j(n), N(c);
		}
		Q(!0);
	}, [t]), ut = import_react.useCallback((a) => {
		var g, E;
		let n = d.current;
		if (!I && (!J.current.isIOS || !a.clipboardData || !n)) return;
		let c = a.clipboardData.getData("text/plain"), b = I ? I(c) : c;
		a.preventDefault();
		let f = (g = d.current) == null ? void 0 : g.selectionStart, s = (E = d.current) == null ? void 0 : E.selectionEnd, v = (f !== s ? l.slice(0, f) + b + l.slice(s) : l.slice(0, f) + b + l.slice(f)).slice(0, t);
		if (v.length > 0 && p && !p.test(v)) return;
		n.value = v, O(v);
		let B = Math.min(v.length, t - 1), _ = v.length;
		n.setSelectionRange(B, _), j(B), N(_);
	}, [
		t,
		O,
		I,
		p,
		l
	]), It = import_react.useMemo(() => ({
		position: "relative",
		cursor: i.disabled ? "default" : "text",
		userSelect: "none",
		WebkitUserSelect: "none",
		pointerEvents: "none"
	}), [i.disabled]), dt = import_react.useMemo(() => ({
		position: "absolute",
		inset: 0,
		width: k.willPushPWMBadge ? `calc(100% + ${k.PWM_BADGE_SPACE_WIDTH})` : "100%",
		clipPath: k.willPushPWMBadge ? `inset(0 ${k.PWM_BADGE_SPACE_WIDTH} 0 0)` : void 0,
		height: "100%",
		display: "flex",
		textAlign: u,
		opacity: "1",
		color: "transparent",
		pointerEvents: "all",
		background: "transparent",
		caretColor: "transparent",
		border: "0 solid transparent",
		outline: "0 solid transparent",
		boxShadow: "none",
		lineHeight: "1",
		letterSpacing: "-.5em",
		fontSize: "var(--root-height, 16px)",
		fontFamily: "monospace",
		fontVariantNumeric: "tabular-nums"
	}), [
		k.PWM_BADGE_SPACE_WIDTH,
		k.willPushPWMBadge,
		u
	]), yt = import_react.useMemo(() => {
		var a;
		return import_react.createElement("input", Pt(bt({ autoComplete: i.autoComplete || "one-time-code" }, i), {
			"data-input-otp": !0,
			"data-input-otp-placeholder-shown": l.length === 0 || void 0,
			"data-input-otp-mss": H,
			"data-input-otp-mse": A,
			inputMode: x,
			pattern: p == null ? void 0 : p.source,
			"aria-placeholder": T,
			style: dt,
			maxLength: t,
			value: l,
			ref: d,
			spellCheck: (a = i.spellCheck) != null ? a : !1,
			onPaste: (n) => {
				var c;
				ut(n), (c = i.onPaste) == null || c.call(i, n);
			},
			onChange: st,
			onMouseOver: (n) => {
				var c;
				it(!0), (c = i.onMouseOver) == null || c.call(i, n);
			},
			onMouseLeave: (n) => {
				var c;
				it(!1), (c = i.onMouseLeave) == null || c.call(i, n);
			},
			onFocus: (n) => {
				var c;
				lt(), (c = i.onFocus) == null || c.call(i, n);
			},
			onBlur: (n) => {
				var c;
				Q(!1), (c = i.onBlur) == null || c.call(i, n);
			}
		}));
	}, [
		st,
		lt,
		ut,
		x,
		dt,
		t,
		A,
		H,
		T,
		i,
		p == null ? void 0 : p.source,
		l
	]), tt = import_react.useMemo(() => ({
		slots: Array.from({ length: t }).map((a, n) => {
			var s;
			let c = L && H !== null && A !== null && (H === A && n === H || n >= H && n < A), b = l[n] !== void 0 ? l[n] : null;
			return {
				char: b,
				placeholderChar: l[0] !== void 0 ? null : (s = T == null ? void 0 : T[n]) != null ? s : null,
				isActive: c,
				hasFakeCaret: c && b === null
			};
		}),
		isFocused: L,
		isHovering: !i.disabled && ct
	}), [
		L,
		ct,
		t,
		A,
		H,
		T,
		i.disabled,
		l
	]), Dt = import_react.useMemo(() => S ? S(tt) : import_react.createElement(Nt.Provider, { value: tt }, R), [
		R,
		tt,
		S
	]);
	return import_react.createElement(import_react.Fragment, null, y !== null && import_react.createElement("noscript", null, import_react.createElement("style", null, y)), import_react.createElement("div", {
		ref: K,
		"data-input-otp-container": !0,
		translate: "no",
		style: It,
		className: q
	}, Dt, import_react.createElement("div", { style: {
		position: "absolute",
		inset: 0,
		pointerEvents: "none"
	} }, yt)));
});
$t.displayName = "Input";
function F(o, r) {
	try {
		o.insertRule(r);
	} catch (t) {
		console.warn("input-otp could not insert CSS rule:", r);
	}
}
var Ft = `
[data-input-otp] {
  --nojs-bg: white !important;
  --nojs-fg: black !important;

  background-color: var(--nojs-bg) !important;
  color: var(--nojs-fg) !important;
  caret-color: var(--nojs-fg) !important;
  letter-spacing: .25em !important;
  text-align: center !important;
  border: 1px solid var(--nojs-fg) !important;
  border-radius: 4px !important;
  width: 100% !important;
}
@media (prefers-color-scheme: dark) {
  [data-input-otp] {
    --nojs-bg: black !important;
    --nojs-fg: white !important;
  }
}`;
//#endregion
export { Nt as n, $t as t };
