//#region node_modules/.nitro/vite/services/ssr/assets/study-illustration-CcH1CutX.js
var study_illustration_default = "/assets/study-illustration-Bm-oErrO.jpg";
//#endregion
export { study_illustration_default as t };
