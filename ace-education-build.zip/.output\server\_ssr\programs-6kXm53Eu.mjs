import { i as __toESM } from "../_runtime.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { R as ArrowRight, j as CircleCheck } from "../_libs/lucide-react.mjs";
import { d as boards, f as cn, l as SectionHeading, m as programs, o as Placeholder, p as contact, r as ContactSection, s as ProgramCard, u as achieverGroups } from "./ContactSection-BXmyUUuK.mjs";
import { t as programs_illustration_default } from "./programs-illustration-j7FCCwlT.mjs";
import { i as TabsTrigger$1, n as TabsContent$1, r as TabsList$1, t as Tabs$1 } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/programs-6kXm53Eu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Tabs$1;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList$1, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = TabsList$1.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger$1, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = TabsTrigger$1.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent$1, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = TabsContent$1.displayName;
var total = achieverGroups.reduce((n, g) => n + g.students.length, 0);
function SectionTabs() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-labelledby": "more-heading",
		className: "container-ace py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			id: "more-heading",
			className: "text-3xl font-semibold text-primary md:text-4xl",
			children: "More about ACE"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "about",
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
				className: "h-auto w-full flex-wrap justify-start gap-1 rounded-2xl bg-secondary p-1.5",
				children: [
					"About",
					"Results",
					"Gallery",
					"Careers",
					"Contact"
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: t.toLowerCase(),
					className: "rounded-xl px-5 py-2.5 font-semibold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
					children: t
				}, t))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "about",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border bg-card p-8 shadow-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-2xl font-semibold text-primary",
								children: "Education, redefined."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 max-w-3xl text-muted-foreground",
								children: [
									"ACE is a coaching institute in Lakshmi Nagar, Hubballi, offering programs for Classes VIII, IX & X across ICSE, CBSE and State Board — guided by one idea: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "from concepts to confidence" }),
									"."
								]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "results",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border bg-card p-8 shadow-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-2xl font-semibold text-primary",
									children: [
										total,
										" achievers in ",
										contact.achieversYear
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-muted-foreground",
									children: "Across NEET / IIT JEE, Class X, Class IX and Class VIII."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/admissions",
									hash: "achievers",
									className: "mt-4 inline-block font-bold text-sky-border underline",
									children: "See all achievers →"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "gallery",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Placeholder, {
							title: "Gallery",
							children: "Photos of classrooms and events will appear here once ACE shares them."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "careers",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Placeholder, {
							title: "Careers at ACE",
							children: [
								"Teaching openings will be listed here. Until then, call ",
								contact.phoneDisplay,
								" to ask about roles."
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "contact",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 rounded-2xl border bg-card p-8 shadow-card md:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold uppercase text-muted-foreground",
									children: "Phone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "font-bold text-primary",
									href: contact.phoneHref,
									children: contact.phoneDisplay
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold uppercase text-muted-foreground",
									children: "Address"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-primary",
									children: contact.addressLines.join(" ")
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold uppercase text-muted-foreground",
										children: "Online"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "block text-sm font-semibold text-primary",
										href: contact.websiteHref,
										target: "_blank",
										rel: "noreferrer",
										children: contact.website
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										className: "block text-sm font-semibold text-primary",
										href: contact.instagramHref,
										target: "_blank",
										rel: "noreferrer",
										children: ["@", contact.instagram]
									})
								] })
							]
						})
					})
				]
			})]
		})]
	});
}
var steps = [
	{
		t: "Bridge the gaps",
		d: "Strengthen concepts, knowledge and skills where the curriculum leaves gaps."
	},
	{
		t: "Build the foundation",
		d: "Move from school learning towards competitive excellence in PCMB & Reasoning."
	},
	{
		t: "Test & remediate",
		d: "Curated tests with structured results and remedial support."
	},
	{
		t: "Ace the boards",
		d: "Comprehensive, NCERT-aligned board preparation."
	}
];
function ProgramsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "relative overflow-hidden bg-navy-pattern text-navy-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace grid items-center gap-10 py-16 md:py-24 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fade-up",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold uppercase tracking-[0.2em] text-gold",
							children: "Programs for Class VIII, IX & X"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-4 text-5xl font-semibold leading-[1.05] md:text-6xl",
							children: ["Learning that grows ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "italic text-gold",
								children: "with every class."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-lg opacity-85",
							children: "From closing gaps to building competitive strength, ACE's programs take students from concepts to confidence — for ICSE, CBSE and State Board."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#programs",
								className: "rounded-full bg-gold px-7 py-3.5 font-bold text-gold-foreground transition hover:-translate-y-0.5",
								children: "Explore programs"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#enquire",
								className: "inline-flex items-center gap-2 rounded-full border-2 border-navy-foreground/40 px-7 py-3.5 font-bold hover:border-gold hover:text-gold",
								children: ["Enquire Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "size-4",
									"aria-hidden": true
								})]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: programs_illustration_default,
					alt: "Teacher guiding students through geometry at a whiteboard",
					width: 1280,
					height: 960,
					className: "fade-up rounded-3xl border-4 border-gold/70 shadow-lift [animation-delay:150ms]"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "programs",
			className: "container-ace scroll-mt-24 py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "What we offer",
				title: "Six programs, one goal",
				intro: "Each program focuses on one part of a student's growth. Students can combine them as they need."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: programs.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgramCard, {
					program: p,
					index: i
				}, p.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace grid gap-12 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Our approach",
					title: "How students move forward"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 space-y-5",
					children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-4 rounded-2xl bg-card p-5 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 shrink-0 place-items-center rounded-full bg-primary font-display font-bold text-primary-foreground",
							children: i + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold text-primary",
							children: s.t
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: s.d
						})] })]
					}, s.t))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-navy-pattern p-8 text-navy-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold uppercase tracking-[0.2em] text-gold",
							children: "Boards supported"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-wrap gap-3",
							children: boards.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-xl border-2 border-gold px-5 py-3 font-display text-2xl font-semibold",
								children: b
							}, b))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border-2 border-sky-border/40 bg-card p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-[0.2em] text-sky-border",
								children: "Why ACE"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-3 text-sm",
								children: [
									"Programs for Classes VIII, IX & X under one roof",
									"Foundation covering Physics, Chemistry, Maths, Biology & Reasoning",
									"Morning Math Mastery classes",
									"Kannada & Hindi language support",
									"Proven results — see our 2025–26 achievers"
								].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
										className: "size-5 shrink-0 text-success",
										"aria-hidden": true
									}), x]
								}, x))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/admissions",
								hash: "achievers",
								className: "mt-5 inline-flex items-center gap-1 font-bold text-sky-border",
								children: ["Meet the achievers ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "size-4",
									"aria-hidden": true
								})]
							})
						]
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTabs, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactSection, { title: `Enquire for ${contact.admissionYear}` })
	] });
}
//#endregion
export { ProgramsPage as component };
