//#region node_modules/.nitro/vite/services/ssr/assets/programs-illustration-j7FCCwlT.js
var programs_illustration_default = "/assets/programs-illustration-DOYnd2P0.jpg";
//#endregion
export { programs_illustration_default as t };
