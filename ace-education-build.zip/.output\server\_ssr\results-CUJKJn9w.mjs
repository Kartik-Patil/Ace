import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { o as Sparkles } from "../_libs/lucide-react.mjs";
import { i as Faq, l as SectionHeading, n as AchieverCard, p as contact, r as ContactSection, t as AceWord, u as achieverGroups } from "./ContactSection-BXmyUUuK.mjs";
import { t as Reveal } from "./Reveal-CXClgHMJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/results-CUJKJn9w.js
var import_jsx_runtime = require_jsx_runtime();
function ResultsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-navy-pattern text-navy-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-ace py-16 text-center md:py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fade-up",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "inline-flex items-center gap-2 rounded-full bg-gold px-4 py-1.5 text-sm font-bold text-gold-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
									className: "size-4",
									"aria-hidden": true
								}),
								" Academic Year ",
								contact.achieversYear
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-6 text-5xl font-semibold leading-[1.05] md:text-6xl lg:text-7xl",
							children: ["Our ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "italic text-gold",
								children: "Achievers"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mx-auto mt-6 max-w-xl text-lg opacity-85",
							children: [
								"These results speak for themselves. Congratulations to every student who worked hard and made ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }),
								" proud."
							]
						})
					]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "achievers",
			className: "container-ace scroll-mt-24 py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					variant: "fade-up",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: `Academic Year ${contact.achieversYear}`,
						title: "Results that inspire",
						intro: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							"Results exactly as reported by ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
							" for the 2025–26 academic year."
						] })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 space-y-16",
					children: achieverGroups.map((g, gi) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						variant: "slide-left",
						delay: gi * 60,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mb-6 inline-block rounded-full bg-sky px-4 py-1.5 text-lg font-semibold text-primary",
							children: g.title
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-5 md:grid-cols-4",
						children: g.students.map((s, si) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							variant: "zoom-in",
							delay: si * 80,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AchieverCard, { a: s })
						}, s.name))
					})] }, g.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-xs text-muted-foreground",
					children: [
						"*AIR as printed on the ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
						" flyer."
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace grid gap-10 lg:grid-cols-[1fr_1.5fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					variant: "slide-left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: "FAQ",
						title: "Questions parents ask",
						intro: "Can't find your answer? Call us on +91 91484 86661."
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					variant: "slide-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactSection, {})
	] });
}
//#endregion
export { ResultsPage as component };
