//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D9in5pwR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/pixel-perfect-replay-6661/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/admissions",
			"/career",
			"/contact",
			"/courses",
			"/home",
			"/programs",
			"/results"
		],
		preloads: ["/assets/index-DAUwYgrr.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DAUwYgrr.js"
		} }]
	},
	"/about": {
		filePath: "D:/pixel-perfect-replay-6661/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DV7wLxHB.js", "/assets/ExamReadySection-B7BvG-O5.js"]
	},
	"/career": {
		filePath: "D:/pixel-perfect-replay-6661/src/routes/career.tsx",
		children: void 0,
		preloads: ["/assets/career-CU06TP5n.js"]
	},
	"/contact": {
		filePath: "D:/pixel-perfect-replay-6661/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-CU06TP5n.js"]
	},
	"/courses": {
		filePath: "D:/pixel-perfect-replay-6661/src/routes/courses.tsx",
		children: void 0,
		preloads: [
			"/assets/courses-C_p_V1RM.js",
			"/assets/play-BdHRiBG3.js",
			"/assets/programs-illustration-BSZ4ke_8.js"
		]
	},
	"/home": {
		filePath: "D:/pixel-perfect-replay-6661/src/routes/home.tsx",
		children: void 0,
		preloads: ["/assets/home-6VT0NFtY.js", "/assets/ExamReadySection-B7BvG-O5.js"]
	},
	"/programs": {
		filePath: "D:/pixel-perfect-replay-6661/src/routes/programs.tsx",
		children: void 0,
		preloads: ["/assets/programs-BEI5yGIp.js", "/assets/programs-illustration-BSZ4ke_8.js"]
	},
	"/results": {
		filePath: "D:/pixel-perfect-replay-6661/src/routes/results.tsx",
		children: void 0,
		preloads: ["/assets/results-Bf2Dw05B.js"]
	}
} });
//#endregion
export { tsrStartManifest };
