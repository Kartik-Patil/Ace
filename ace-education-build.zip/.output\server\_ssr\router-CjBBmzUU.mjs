import { i as __toESM } from "../_runtime.mjs";
import { G as redirect, _ as createFileRoute, b as useRouter, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRouteWithContext, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { D as FlaskConical, E as Globe, I as BookOpen, P as CalendarCheck2, R as ArrowRight, T as HeartHandshake, _ as Menu, a as Target, g as MessageSquare, i as TrendingUp, k as Compass, m as Phone, n as UsersRound, o as Sparkles, r as Trophy, s as ShieldCheck, t as X, v as MapPin, w as Instagram, x as Lightbulb } from "../_libs/lucide-react.mjs";
import { a as LogoFallback, c as SafeImage, d as boards, i as Faq, l as SectionHeading, p as contact, r as ContactSection, t as AceWord } from "./ContactSection-BXmyUUuK.mjs";
import { t as study_illustration_default } from "./study-illustration-CcH1CutX.mjs";
import { t as Reveal } from "./Reveal-CXClgHMJ.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CjBBmzUU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DO7kXwr4.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message: describeThrown(error),
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var MAX_SERIALIZED_LENGTH = 2e3;
function describeThrown(error) {
	if (error instanceof Response) return `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`;
	if (error instanceof Error) return error.message;
	if (typeof error === "string") return error;
	const { message } = error ?? {};
	if (typeof message === "string" && message.length > 0) return message;
	try {
		return JSON.stringify(error)?.slice(0, MAX_SERIALIZED_LENGTH) ?? String(error);
	} catch {
		return String(error);
	}
}
var nav = [
	{
		to: "/home",
		label: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}), " Experience"] })
	},
	{
		to: "/admissions",
		label: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Join ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {})] })
	},
	{
		to: "/courses",
		label: "Explore Programs"
	},
	{
		to: "/results",
		label: "Our Achievers"
	},
	{
		to: "/career",
		label: "Career"
	}
];
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b bg-background/90 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-ace flex h-20 items-center justify-between gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/home",
					className: "shrink-0",
					"aria-label": "ACE – Education Redefined, home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafeImage, {
						src: "/images/ace-logo.png",
						alt: "ACE – Education Redefined",
						width: 700,
						height: 250,
						className: "h-[66px] w-auto object-contain",
						fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoFallback, {})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Main",
					className: "hidden flex-1 items-center gap-1 lg:flex",
					children: nav.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: n.to,
						className: "whitespace-nowrap rounded-full px-4 py-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-primary",
						activeProps: { className: "bg-secondary text-primary" },
						children: n.label
					}, n.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden items-center gap-4 lg:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: contact.whatsappHref,
						target: "_blank",
						rel: "noreferrer",
						className: "flex items-center gap-2 whitespace-nowrap text-sm font-semibold text-primary transition hover:text-gold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "size-4 text-emerald-600",
								"aria-hidden": true
							}),
							" WhatsApp ",
							contact.phoneDisplay
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#enquire",
						className: "whitespace-nowrap rounded-full bg-gold px-5 py-2.5 text-sm font-bold text-gold-foreground transition hover:-translate-y-0.5 hover:shadow-card",
						children: "Enquire Now"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "rounded-lg p-2 text-primary lg:hidden",
					"aria-label": open ? "Close menu" : "Open menu",
					"aria-expanded": open,
					onClick: () => setOpen((o) => !o),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			"aria-label": "Mobile",
			className: "border-t bg-background lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace flex flex-col gap-1 py-4",
				children: [
					nav.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: n.to,
						onClick: () => setOpen(false),
						className: "rounded-lg px-3 py-3 font-semibold",
						activeProps: { className: "bg-secondary text-primary" },
						children: n.label
					}, n.to)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: contact.whatsappHref,
						target: "_blank",
						rel: "noreferrer",
						className: "flex items-center gap-2 px-3 py-3 font-semibold text-primary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4 text-emerald-600" }),
							" WhatsApp ",
							contact.phoneDisplay
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#enquire",
						onClick: () => setOpen(false),
						className: "mt-1 rounded-full bg-gold px-5 py-3 text-center font-bold text-gold-foreground",
						children: "Enquire Now"
					})
				]
			})
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "bg-navy-pattern text-navy-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-ace grid gap-10 py-14 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "inline-block rounded-xl bg-card p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafeImage, {
								src: "/images/ace-logo.png",
								alt: "ACE – Education Redefined",
								className: "h-10 w-auto",
								loading: "lazy",
								fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoFallback, {})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 max-w-sm font-display text-2xl italic",
							children: [
								"“",
								contact.tagline,
								"”"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm opacity-75",
							children: "Programs for Classes VIII, IX & X · ICSE · CBSE · State Board"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-bold uppercase tracking-widest text-gold",
					children: "Explore"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admissions",
						className: "hover:text-gold",
						children: "Admissions & Achievers"
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/courses",
						className: "hover:text-gold",
						children: "Programs"
					}) })]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-bold uppercase tracking-widest text-gold",
					children: "Reach us"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
								className: "mt-0.5 size-4 shrink-0",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: contact.mapsHref,
								target: "_blank",
								rel: "noreferrer",
								className: "hover:text-gold",
								children: contact.addressLines.join(" ")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "size-4",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: contact.phoneHref,
								className: "hover:text-gold",
								children: contact.phoneDisplay
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
								className: "size-4",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: contact.websiteHref,
								target: "_blank",
								rel: "noreferrer",
								className: "hover:text-gold",
								children: contact.website
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {
								className: "size-4",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: contact.instagramHref,
								target: "_blank",
								rel: "noreferrer",
								className: "hover:text-gold",
								children: contact.instagram
							})]
						})
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-navy-foreground/15 py-5 text-center text-xs opacity-70",
			children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }),
				" – Education Redefined, Hubballi"
			]
		})]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$9 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "ACE – Education Redefined" },
			{
				name: "description",
				content: "ACE coaching institute, Hubballi — programs for Classes VIII, IX & X."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant:ital,wght@0,300..700;1,300..700&family=Niramit:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap"
			},
			{
				rel: "icon",
				type: "image/png",
				href: "/favicon.png"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$9.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
var Route$8 = createFileRoute("/")({
	beforeLoad: () => {
		throw redirect({ to: "/home" });
	},
	head: () => ({ meta: [
		{ title: "ACE – Education Redefined | Hubballi" },
		{
			name: "description",
			content: "ACE coaching for Classes VIII, IX & X in Hubballi. Admissions open for 2027–28."
		},
		{
			property: "og:title",
			content: "ACE – Education Redefined"
		},
		{
			property: "og:description",
			content: "From Concepts to Confidence. Programs for Classes VIII–X in Hubballi."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] })
});
var $$splitComponentImporter$6 = () => import("./about-Drb3hMFd.mjs");
var Route$7 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: "About Us | ACE Education, Hubballi" }, {
		name: "description",
		content: "About Us – ACE Education, Hubballi. From Concepts to Confidence. Established in 2022 | 500+ Students | Academic Excellence & Beyond Classroom Learning."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
function WhyParentsTrustRadialSection() {
	const [activeIdx, setActiveIdx] = (0, import_react.useState)(0);
	const reasons = [
		{
			id: 0,
			title: "Strong Conceptual Foundations",
			shortTitle: [
				"STRONG",
				"CONCEPTUAL",
				"FOUNDATIONS"
			],
			sub: "PCMB Core Mastery",
			tag: "Deep Understanding",
			icon: BookOpen,
			colorType: "gold",
			description: "We focus on building a crystal-clear understanding of fundamental concepts in Physics, Chemistry, Mathematics and Biology, replacing rote memorisation with analytical clarity.",
			parentBenefit: "Ensures your child doesn't just pass school tests, but truly grasps concepts for competitive JEE/NEET futures."
		},
		{
			id: 1,
			title: "Experiential & Activity Learning",
			shortTitle: [
				"EXPERIENTIAL",
				"& ACTIVITY-BASED",
				"LEARNING"
			],
			sub: "Practical Science Lab",
			tag: "Hands-on Science",
			icon: FlaskConical,
			colorType: "navy",
			description: "Real science experiments, visual demonstrations and hands-on activities make abstract classroom theories tangible, engaging and permanently memorable.",
			parentBenefit: "Ignites genuine curiosity in science and mathematics instead of subject fear or dread."
		},
		{
			id: 2,
			title: "Skills for Holistic Growth",
			shortTitle: [
				"SKILLS FOR",
				"HOLISTIC",
				"DEVELOPMENT"
			],
			sub: "Analytical & Communication",
			tag: "Beyond Textbooks",
			icon: MessageSquare,
			colorType: "gold",
			description: "We intentionally nurture active communication, structured writing, analytical reasoning, and creative problem solving alongside standard academic syllabus.",
			parentBenefit: "Develops an articulate, confident student equipped for entrance exams, presentations, and interviews."
		},
		{
			id: 3,
			title: "Interactive & Student-Centric",
			shortTitle: [
				"INTERACTIVE",
				"& STUDENT-CENTRIC",
				"TEACHING"
			],
			sub: "Small Batches & Care",
			tag: "Individual Attention",
			icon: UsersRound,
			colorType: "navy",
			description: "Our classrooms encourage active discussions, questioning and collaborative inquiry in small batch sizes where no student is left feeling invisible.",
			parentBenefit: "Your child receives the personal faculty attention and mentoring often missing in crowded schools."
		},
		{
			id: 4,
			title: "Continuous Assessment & Guidance",
			shortTitle: [
				"CONTINUOUS",
				"ASSESSMENT &",
				"GUIDANCE"
			],
			sub: "Diagnostic Error Mapping",
			tag: "Progress Tracking",
			icon: TrendingUp,
			colorType: "gold",
			description: "Regular chapter-wise assessments, transparent performance reporting, diagnostic error mapping and 1-on-1 remedial doubt-solving sessions.",
			parentBenefit: "Identifies and fixes weak spots immediately before they snowball into major board exam hurdles."
		},
		{
			id: 5,
			title: "Confidence & Exam Preparedness",
			shortTitle: [
				"CONFIDENCE &",
				"EXAMINATION",
				"PREPAREDNESS"
			],
			sub: "Zero Exam Fear",
			tag: "Board Ready",
			icon: ShieldCheck,
			colorType: "navy",
			description: "Simulated mock test drills, time-management coaching and step-marking answer writing practice help students eliminate fear and approach exams with calm composure.",
			parentBenefit: "Transforms examination anxiety into calm, self-assured performance on board exam day."
		}
	];
	const cx = 310;
	const cy = 370;
	const rIn = 250;
	const rOut = 445;
	const rTrack = 215;
	const wedgeConfigs = [
		{
			start: -71,
			end: -49,
			mid: -60
		},
		{
			start: -46.5,
			end: -24.5,
			mid: -35.5
		},
		{
			start: -22,
			end: 0,
			mid: -11
		},
		{
			start: 2.5,
			end: 24.5,
			mid: 13.5
		},
		{
			start: 27,
			end: 49,
			mid: 38
		},
		{
			start: 51.5,
			end: 73.5,
			mid: 62.5
		}
	];
	const polarToCartesian = (centerX, centerY, radius, angleInDegrees) => {
		const angleInRadians = (angleInDegrees - 0) * Math.PI / 180;
		return {
			x: centerX + radius * Math.cos(angleInRadians),
			y: centerY + radius * Math.sin(angleInRadians)
		};
	};
	const describeAnnularSector = (centerX, centerY, radiusIn, radiusOut, startAngle, endAngle) => {
		const p1 = polarToCartesian(centerX, centerY, radiusIn, startAngle);
		const p2 = polarToCartesian(centerX, centerY, radiusOut, startAngle);
		const p3 = polarToCartesian(centerX, centerY, radiusOut, endAngle);
		const p4 = polarToCartesian(centerX, centerY, radiusIn, endAngle);
		return [
			`M ${p1.x} ${p1.y}`,
			`L ${p2.x} ${p2.y}`,
			`A ${radiusOut} ${radiusOut} 0 0 1 ${p3.x} ${p3.y}`,
			`L ${p4.x} ${p4.y}`,
			`A ${radiusIn} ${radiusIn} 0 0 0 ${p1.x} ${p1.y}`,
			"Z"
		].join(" ");
	};
	const trackStart = polarToCartesian(cx, cy, rTrack, -76);
	const trackEnd = polarToCartesian(cx, cy, rTrack, 76);
	const trackArcD = `M ${trackStart.x} ${trackStart.y} A ${rTrack} ${rTrack} 0 0 1 ${trackEnd.x} ${trackEnd.y}`;
	const currentActiveReason = reasons[activeIdx] ?? reasons[0];
	const ActiveIcon = currentActiveReason.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "why-ace",
		className: "relative overflow-hidden bg-secondary/35 py-20 lg:py-28 border-y border-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(#1b365d_1px,transparent_1px)] [background-size:28px_28px] opacity-[0.035]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -top-32 -left-32 size-96 rounded-full bg-gold/10 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -bottom-32 right-0 size-96 rounded-full bg-primary/10 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						variant: "fade-up",
						className: "text-center max-w-3xl mx-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-[0.2em] text-sky-border mb-3",
								children: "What Makes ACE Different?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-3xl font-extrabold tracking-tight text-primary sm:text-4xl lg:text-5xl",
								children: [
									"6 Reasons Parents Trust",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "relative inline-block",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "italic text-gold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}), " Education"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
											className: "absolute -bottom-2.5 left-0 w-full h-3.5 text-gold overflow-visible",
											viewBox: "0 0 320 12",
											fill: "none",
											preserveAspectRatio: "none",
											"aria-hidden": "true",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
												d: "M3 8.5C65 2.5 190 2 317 7.5",
												stroke: "currentColor",
												strokeWidth: "4.5",
												strokeLinecap: "round"
											})
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-base sm:text-lg text-muted-foreground font-medium",
								children: "Education beyond the classroom. Click or hover any radial pillar below to inspect how our learning approach benefits your child."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-14 hidden lg:block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							variant: "fade-up",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative mx-auto max-w-[960px] select-none",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									viewBox: "0 0 940 740",
									className: "w-full h-auto overflow-visible filter drop-shadow-sm",
									"aria-label": "6 Reasons Parents Trust ACE Education Radial Diagram",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("filter", {
												id: "wedge-shadow",
												x: "-10%",
												y: "-10%",
												width: "125%",
												height: "125%",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feDropShadow", {
													dx: "0",
													dy: "6",
													stdDeviation: "8",
													floodColor: "#1b365d",
													floodOpacity: "0.18"
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("filter", {
												id: "hub-shadow",
												x: "-15%",
												y: "-15%",
												width: "130%",
												height: "130%",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feDropShadow", {
													dx: "0",
													dy: "10",
													stdDeviation: "16",
													floodColor: "#1b365d",
													floodOpacity: "0.12"
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
												id: "goldWedgeGrad",
												x1: "0%",
												y1: "0%",
												x2: "100%",
												y2: "100%",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "0%",
													stopColor: "#f59e0b"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "100%",
													stopColor: "#d97706"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
												id: "goldWedgeActive",
												x1: "0%",
												y1: "0%",
												x2: "100%",
												y2: "100%",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "0%",
													stopColor: "#fbbf24"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "100%",
													stopColor: "#b45309"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
												id: "navyWedgeGrad",
												x1: "0%",
												y1: "0%",
												x2: "100%",
												y2: "100%",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "0%",
													stopColor: "#1e3a66"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "100%",
													stopColor: "#142845"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
												id: "navyWedgeActive",
												x1: "0%",
												y1: "0%",
												x2: "100%",
												y2: "100%",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "0%",
													stopColor: "#2a4c80"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "100%",
													stopColor: "#0d1b30"
												})]
											})
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: trackArcD,
											fill: "none",
											stroke: "#1b365d",
											strokeWidth: "3.5",
											strokeLinecap: "round",
											className: "opacity-70"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: trackStart.x,
											cy: trackStart.y,
											r: "5",
											fill: "#1b365d"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: trackEnd.x,
											cy: trackEnd.y,
											r: "5",
											fill: "#1b365d"
										}),
										reasons.map((item, idx) => {
											const cfg = wedgeConfigs[idx] ?? wedgeConfigs[0];
											const isCurrent = activeIdx === idx;
											const pathD = describeAnnularSector(cx, cy, rIn, rOut, cfg.start, cfg.end);
											const textPos = polarToCartesian(cx, cy, 695 / 2, cfg.mid);
											const nodePos = polarToCartesian(cx, cy, rTrack, cfg.mid);
											const stemTarget = polarToCartesian(cx, cy, 246, cfg.mid);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
												className: "cursor-pointer transition-transform duration-300",
												onClick: () => setActiveIdx(idx),
												onMouseEnter: () => setActiveIdx(idx),
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
														x1: nodePos.x,
														y1: nodePos.y,
														x2: stemTarget.x,
														y2: stemTarget.y,
														stroke: isCurrent ? "#f59e0b" : "#1b365d",
														strokeWidth: isCurrent ? "3" : "2",
														className: "transition-colors duration-200"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
														cx: nodePos.x,
														cy: nodePos.y,
														r: isCurrent ? "8" : "6.5",
														fill: isCurrent ? "#f59e0b" : "#ffffff",
														stroke: "#1b365d",
														strokeWidth: isCurrent ? "3.5" : "3",
														className: "transition-all duration-200"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
														d: pathD,
														fill: item.colorType === "gold" ? isCurrent ? "url(#goldWedgeActive)" : "url(#goldWedgeGrad)" : isCurrent ? "url(#navyWedgeActive)" : "url(#navyWedgeGrad)",
														stroke: "#ffffff",
														strokeWidth: isCurrent ? "6" : "5",
														strokeLinejoin: "round",
														filter: "url(#wedge-shadow)",
														className: `transition-all duration-300 ${isCurrent ? "brightness-105 scale-[1.015] origin-center" : "hover:brightness-105"}`
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
														transform: `rotate(${cfg.mid}, ${textPos.x}, ${textPos.y})`,
														className: "pointer-events-none select-none",
														children: item.shortTitle.map((line, lineIdx) => {
															const yOffset = (lineIdx - (item.shortTitle.length - 1) / 2) * 15;
															return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
																x: textPos.x,
																y: textPos.y + yOffset,
																textAnchor: "middle",
																dominantBaseline: "central",
																fill: "#ffffff",
																className: "font-display font-extrabold text-[12px] tracking-wider",
																style: { letterSpacing: "0.08em" },
																children: line
															}, lineIdx);
														})
													})
												]
											}, item.id);
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
											className: "cursor-default pointer-events-none",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
													cx,
													cy,
													r: "165",
													fill: "#ffffff",
													stroke: "#f8fafc",
													strokeWidth: "4",
													filter: "url(#hub-shadow)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
													cx,
													cy,
													r: "152",
													fill: "none",
													stroke: "#e2e8f0",
													strokeWidth: "1.5",
													strokeDasharray: "4 4"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: cx,
													y: 322,
													textAnchor: "middle",
													fill: "#64748b",
													className: "font-bold text-[11px] uppercase tracking-[0.25em]",
													children: "Why Choose ACE"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: cx,
													y: 348,
													textAnchor: "middle",
													fill: "#1b365d",
													className: "font-display font-extrabold text-[24px] tracking-tight",
													children: "HOW WE NURTURE"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: cx,
													y: 378,
													textAnchor: "middle",
													fill: "#d97706",
													className: "font-display font-black text-[25px] tracking-tight",
													children: "EXCELLENCE"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: cx,
													y: 404,
													textAnchor: "middle",
													fill: "#1b365d",
													className: "font-display font-semibold text-[13px] tracking-wide",
													children: "Classes 8, 9 & 10 · All Boards"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: 235,
													y: 422,
													width: "150",
													height: "24",
													rx: "12",
													fill: "#fef3c7",
													stroke: "#fde68a"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
													x: cx,
													y: 434,
													textAnchor: "middle",
													dominantBaseline: "central",
													fill: "#92400e",
													className: "font-bold text-[9.5px] tracking-wider uppercase",
													children: [
														"★ Reason 0",
														activeIdx + 1,
														" Selected"
													]
												})
											]
										})
									]
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							variant: "fade-up",
							delay: 150,
							className: "mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto max-w-4xl rounded-3xl border-2 border-gold/40 bg-card p-7 shadow-lift transition-all duration-300",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col md:flex-row items-start md:items-center justify-between gap-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `grid size-14 shrink-0 place-items-center rounded-2xl border-2 shadow-sm ${currentActiveReason.colorType === "gold" ? "bg-gold text-gold-foreground border-gold/60" : "bg-primary text-gold border-gold/40"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActiveIcon, { className: "size-7" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "rounded-full bg-gold/15 px-2.5 py-0.5 text-xs font-bold text-gold-foreground",
													children: ["Reason 0", currentActiveReason.id + 1]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-bold text-sky-border uppercase tracking-wider",
													children: currentActiveReason.tag
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "mt-1 font-display text-xl sm:text-2xl font-bold text-primary",
												children: currentActiveReason.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm text-muted-foreground font-medium leading-relaxed max-w-2xl",
												children: currentActiveReason.description
											})
										] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "shrink-0 rounded-2xl border border-sky-border/40 bg-sky/50 p-4 max-w-xs",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] font-bold text-primary flex items-start gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gold font-black",
												children: "★"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-primary font-bold",
													children: "Why it matters to parents:"
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground font-medium",
													children: currentActiveReason.parentBenefit
												})
											] })]
										})
									})]
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-12 space-y-5 lg:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-3xl border-2 border-gold/40 bg-card p-6 text-center shadow-lift",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-bold uppercase tracking-[0.2em] text-sky-border",
									children: "Why Parents Trust ACE"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-1 font-display text-2xl font-extrabold text-primary",
									children: "6 Pillars of Academic Trust"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-muted-foreground font-medium",
									children: "Education beyond the classroom — built on conceptual clarity, individual care, and proven board success."
								})
							]
						}), reasons.map((item, idx) => {
							const Icon = item.icon;
							const isGold = item.colorType === "gold";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								variant: "fade-up",
								delay: idx * 60,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `rounded-2xl border-4 border-white p-5 text-white shadow-lift transition-transform active:scale-[0.98] ${isGold ? "bg-gradient-to-r from-amber-500 to-amber-600" : "bg-gradient-to-r from-navy to-[#152a48]"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-2 font-display text-lg font-extrabold tracking-wide",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 shrink-0" }),
													"0",
													idx + 1,
													". ",
													item.title
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-white/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider",
												children: item.tag
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2.5 text-xs text-white/90 leading-relaxed font-medium",
											children: item.description
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3.5 rounded-xl bg-black/20 p-2.5 text-[11px] text-white/95 border border-white/10",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-amber-200",
													children: "Parent Benefit:"
												}),
												" ",
												item.parentBenefit
											]
										})
									]
								})
							}, item.id);
						})]
					})
				]
			})
		]
	});
}
function EducationalPhilosophyWaveSection() {
	const stages = [
		{
			num: "01",
			numberInt: 1,
			title: "Question with Curiosity",
			subTitle: "Inquiry First",
			detail: "Develop the lifelong habit of asking questions, exploring ideas, and seeking deeper conceptual understanding.",
			icon: Compass,
			position: "above",
			nodeX: 160,
			nodeY: 360,
			textX: 160,
			textY: 100,
			nodeColor: "blue"
		},
		{
			num: "02",
			numberInt: 2,
			title: "Learn with Clarity",
			subTitle: "No Rote Learning",
			detail: "Build strong, logical conceptual foundations in science & math rather than relying on shallow rote memorisation.",
			icon: Lightbulb,
			position: "below",
			nodeX: 390,
			nodeY: 150,
			textX: 390,
			textY: 280,
			nodeColor: "gold"
		},
		{
			num: "03",
			numberInt: 3,
			title: "Think Independently",
			subTitle: "Critical Thinking",
			detail: "Develop the mental agility to analyse problems, reason logically, and approach complex academic challenges with confidence.",
			icon: Target,
			position: "above",
			nodeX: 620,
			nodeY: 360,
			textX: 620,
			textY: 100,
			nodeColor: "blue"
		},
		{
			num: "04",
			numberInt: 4,
			title: "Grow with Discipline",
			subTitle: "Consistent Habits",
			detail: "Cultivate daily consistency, academic responsibility, time management, and a positive, resilient approach to learning.",
			icon: CalendarCheck2,
			position: "below",
			nodeX: 850,
			nodeY: 150,
			textX: 850,
			textY: 280,
			nodeColor: "blue"
		},
		{
			num: "05",
			numberInt: 5,
			title: "Excel with Confidence",
			subTitle: "Proven Success",
			detail: "Apply knowledge effectively under exam conditions, eliminate fear, and emerge as confident, high-ranking achievers.",
			icon: Trophy,
			position: "above",
			nodeX: 1060,
			nodeY: 260,
			textX: 1060,
			textY: 70,
			nodeColor: "gold"
		}
	];
	const getHexagonPoints = (cx, cy, r = 26) => {
		const points = [];
		for (let i = 0; i < 6; i++) {
			const angleDeg = 60 * i - 30;
			const angleRad = Math.PI / 180 * angleDeg;
			const x = cx + r * Math.cos(angleRad);
			const y = cy + r * Math.sin(angleRad);
			points.push(`${x.toFixed(1)},${y.toFixed(1)}`);
		}
		return points.join(" ");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-background py-24 border-y border-border select-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute top-8 right-8 lg:right-16 font-display font-extrabold text-7xl sm:text-8xl lg:text-9xl text-slate-200/40 select-none",
			children: "05"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-ace relative z-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					variant: "fade-up",
					className: "text-center max-w-3xl mx-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-sky-border mb-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-6 h-0.5 bg-sky-border inline-block" }),
								"Our Educational Philosophy",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-6 h-0.5 bg-sky-border inline-block" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-primary",
							children: "Learning Begins with Curiosity."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-2xl sm:text-3xl font-bold tracking-tight text-gold",
							children: "Excellence Follows with Confidence."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-sm sm:text-base text-muted-foreground font-medium max-w-2xl mx-auto",
							children: [
								"Every great achievement begins with the courage to question, the discipline to learn, and the determination to excel. A continuous journey of intellectual transformation at ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
								"."
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 hidden lg:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						variant: "fade-up",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative mx-auto w-full max-w-[1200px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 1200 520",
								className: "w-full h-auto overflow-visible",
								"aria-label": "Educational Philosophy Journey Wave Diagram",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
											id: "waveLineGrad",
											x1: "0%",
											y1: "0%",
											x2: "100%",
											y2: "0%",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "0%",
													stopColor: "#0284c7"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "35%",
													stopColor: "#0ea5e9"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "70%",
													stopColor: "#0284c7"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "100%",
													stopColor: "#d97706"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("filter", {
											id: "hexPodGlowBlue",
											x: "-30%",
											y: "-30%",
											width: "160%",
											height: "160%",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feDropShadow", {
												dx: "0",
												dy: "10",
												stdDeviation: "12",
												floodColor: "#0284c7",
												floodOpacity: "0.25"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("filter", {
											id: "hexPodGlowGold",
											x: "-30%",
											y: "-30%",
											width: "160%",
											height: "160%",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feDropShadow", {
												dx: "0",
												dy: "10",
												stdDeviation: "12",
												floodColor: "#d97706",
												floodOpacity: "0.3"
											})
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M 30,320 \n                     C 80,335 120,360 160,360 \n                     C 230,360 310,150 390,150 \n                     C 470,150 540,360 620,360 \n                     C 700,360 770,150 850,150 \n                     C 930,150 1000,260 1060,260 \n                     C 1100,260 1140,270 1170,275",
										fill: "none",
										stroke: "url(#waveLineGrad)",
										strokeWidth: "4",
										strokeLinecap: "round",
										className: "transition-all duration-500"
									}),
									stages.map((stg) => {
										const Icon = stg.icon;
										const isGold = stg.nodeColor === "gold";
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
											className: "transition-transform duration-300 hover:scale-110 origin-center cursor-default",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
												points: getHexagonPoints(stg.nodeX, stg.nodeY, 27),
												fill: "#ffffff",
												stroke: isGold ? "#f59e0b" : "#0284c7",
												strokeWidth: "2.5",
												filter: isGold ? "url(#hexPodGlowGold)" : "url(#hexPodGlowBlue)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("foreignObject", {
												x: stg.nodeX - 14,
												y: stg.nodeY - 14,
												width: "28",
												height: "28",
												className: "pointer-events-none",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "grid size-full place-items-center",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `size-4.5 ${isGold ? "text-gold" : "text-sky-600"}` })
												})
											})]
										}, stg.num);
									}),
									stages.map((stg) => {
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("foreignObject", {
											x: stg.textX - 110,
											y: stg.textY,
											width: "220",
											height: "190",
											className: "overflow-visible",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative group text-left",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "pointer-events-none absolute -top-4 right-0 font-display font-black text-6xl text-slate-200/70 select-none transition-transform duration-300 group-hover:scale-105 group-hover:text-gold/25",
													children: stg.numberInt
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative z-10 pr-6",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[10px] font-bold uppercase tracking-wider text-sky-border",
															children: stg.subTitle
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
															className: "mt-1 font-display text-base font-extrabold text-primary leading-snug",
															children: stg.title
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "mt-1.5 text-xs text-muted-foreground font-medium leading-relaxed",
															children: stg.detail
														})
													]
												})]
											})
										}, `text-${stg.num}`);
									})
								]
							})
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-12 relative lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-6 top-8 bottom-8 w-1 bg-gradient-to-b from-sky-500 via-sky-400 to-gold rounded-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-8 pl-14",
						children: stages.map((stg, i) => {
							const Icon = stg.icon;
							const isGold = stg.nodeColor === "gold";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								variant: "fade-up",
								delay: i * 80,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative group rounded-2xl border-2 border-border bg-card p-5 shadow-sm transition hover:border-gold hover:shadow-lift",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "absolute -left-[54px] top-5 size-11 grid place-items-center rounded-xl bg-white border-2 border-sky-500 shadow-md",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `size-5 ${isGold ? "text-gold" : "text-sky-600"}` })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "pointer-events-none absolute top-3 right-4 font-display font-black text-5xl text-slate-200/70 select-none",
											children: stg.numberInt
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative z-10 pr-8",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "inline-block rounded bg-gold/15 px-2 py-0.5 text-[10px] font-bold text-gold-foreground uppercase tracking-wide",
													children: stg.subTitle
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "mt-2 font-display text-lg font-bold text-primary",
													children: stg.title
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-xs text-muted-foreground font-medium leading-relaxed",
													children: stg.detail
												})
											]
										})
									]
								})
							}, stg.num);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-16 pt-6 border-t border-border/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-semibold text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-primary",
								children: "ACE EDUCATION HUBBALLI"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "From Concepts to Confidence" })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#enquire",
						className: "inline-flex items-center gap-1.5 font-bold text-primary hover:text-gold transition",
						children: "Enquire Now →"
					})]
				})
			]
		})]
	});
}
function CommitmentsInfographicSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-background py-24 border-y border-border select-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-0 opacity-[0.035] flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 1000 500",
				className: "w-full h-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M 150,120 Q 200,80 250,110 T 320,180 T 260,260 T 210,210 Z\n               M 450,90 Q 520,60 580,100 T 680,140 T 750,220 T 670,280 T 520,240 Z\n               M 240,320 Q 290,300 320,350 T 280,440 T 220,400 Z\n               M 720,320 Q 780,290 820,340 T 800,420 T 730,380 Z",
					fill: "currentColor"
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-ace relative z-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					variant: "fade-up",
					className: "text-center max-w-3xl mx-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-sky-border mb-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-6 h-0.5 bg-sky-border inline-block" }),
								"The ACE Promise to Parents",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-6 h-0.5 bg-sky-border inline-block" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-3xl font-extrabold tracking-tight text-primary sm:text-4xl lg:text-5xl",
							children: [
								"Our 5 Unwavering Commitments",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative inline-block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "italic text-gold",
										children: "to Your Child"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										className: "absolute -bottom-2.5 left-0 w-full h-3.5 text-gold overflow-visible",
										viewBox: "0 0 320 12",
										fill: "none",
										preserveAspectRatio: "none",
										"aria-hidden": "true",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: "M3 8.5C65 2.5 190 2 317 7.5",
											stroke: "currentColor",
											strokeWidth: "4.5",
											strokeLinecap: "round"
										})
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-5 text-base sm:text-lg text-muted-foreground font-medium",
							children: [
								"When you enrol your ward at ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
								", you are investing in a structured, proven ecosystem built on conceptual rigour, individual care, and lifelong confidence."
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-3 items-start",
					children: [
						{
							num: "1",
							color: "#e11d48",
							lightBg: "rgba(225, 29, 72, 0.08)",
							icon: BookOpen,
							title: "FOUNDATIONS",
							shortDesc: "PCMB core mastery with analytical clarity.",
							fullDesc: "Replacing rote memorisation with conceptual depth across Physics, Chemistry, Math & Biology.",
							tag: "PCMB Mastery"
						},
						{
							num: "2",
							color: "#0d9488",
							lightBg: "rgba(13, 148, 136, 0.08)",
							icon: FlaskConical,
							title: "BEYOND CLASSROOM",
							shortDesc: "Hands-on experiments & practical science.",
							fullDesc: "Demonstrations and scientific lab applications that turn abstract theory into tangible knowledge.",
							tag: "Applied Science"
						},
						{
							num: "3",
							color: "#d97706",
							lightBg: "rgba(217, 119, 6, 0.08)",
							icon: MessageSquare,
							title: "ESSENTIAL SKILLS",
							shortDesc: "Reasoning & creative problem solving.",
							fullDesc: "Communication, structured writing, and analytical thinking developed alongside the syllabus.",
							tag: "Holistic Growth"
						},
						{
							num: "4",
							color: "#1b365d",
							lightBg: "rgba(27, 54, 93, 0.08)",
							icon: ShieldCheck,
							title: "BOARD EXCELLENCE",
							shortDesc: "Structured ICSE, CBSE & State Board prep.",
							fullDesc: "NCERT-aligned curriculum coverage delivering consistent 100% pass and distinction results.",
							tag: "Board Success"
						},
						{
							num: "5",
							color: "#7c3aed",
							lightBg: "rgba(124, 58, 237, 0.08)",
							icon: HeartHandshake,
							title: "CONFIDENCE",
							shortDesc: "Timed mock drills & zero exam anxiety.",
							fullDesc: "Individual faculty mentoring and continuous feedback loops that eliminate examination fear.",
							tag: "Zero Exam Fear"
						}
					].map((item, idx) => {
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							variant: "fade-up",
							delay: idx * 80,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group relative flex flex-col items-center justify-start p-2 transition-all duration-300 hover:-translate-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative w-full max-w-[280px] sm:max-w-[260px] lg:max-w-none aspect-[340/240]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
											viewBox: "0 0 340 240",
											className: "w-full h-full overflow-visible filter drop-shadow-sm transition-transform duration-300 group-hover:scale-[1.02]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
													cx: "208",
													cy: "120",
													r: "94",
													fill: item.lightBg
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: "72",
													y: "162",
													textAnchor: "middle",
													fill: item.color,
													className: "font-display font-black text-[130px] select-none tracking-tighter",
													style: { fontFamily: "var(--font-display, inherit)" },
													children: item.num
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
													d: "M 130 65 A 96 96 0 1 1 130 175",
													fill: "none",
													stroke: item.color,
													strokeWidth: "4.5",
													strokeLinecap: "round",
													className: "transition-all duration-300 group-hover:stroke-width-[5.5]"
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute left-[61.2%] top-[50%] -translate-x-1/2 -translate-y-1/2 w-[42%] max-w-[130px] flex flex-col items-center justify-center text-center px-1 pointer-events-none select-none",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mb-1.5 grid size-7 place-items-center rounded-full bg-white shadow-2xs",
													style: { color: item.color },
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "font-display font-extrabold text-[11px] leading-tight uppercase tracking-wider",
													style: { color: item.color },
													children: item.title
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-[9.5px] leading-snug text-muted-foreground font-semibold line-clamp-2",
													children: item.shortDesc
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-xs text-muted-foreground text-center font-medium leading-relaxed px-1",
										children: item.fullDesc
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-3 inline-block rounded-full px-3 py-1 text-[10.5px] font-bold uppercase tracking-wider transition-colors duration-200",
										style: {
											backgroundColor: item.lightBg,
											color: item.color
										},
										children: item.tag
									})
								]
							})
						}, item.num);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-16 pt-8 border-t border-border/80 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display font-bold text-xs uppercase tracking-[0.25em] text-muted-foreground",
							children: "INFOGRAPHICS ELEMENTS · EDUCATIONAL COMMITMENT ECOSYSTEM"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-semibold text-primary",
							children: "From Concepts to Confidence · Guiding over 500+ students towards academic brilliance."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#enquire",
								className: "inline-flex items-center gap-2 rounded-full bg-gold px-6 py-2.5 text-xs font-bold text-gold-foreground transition hover:-translate-y-0.5 hover:shadow-md",
								children: ["Enquire Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
							})
						})
					]
				})
			]
		})]
	});
}
function AdmissionPathwayPuzzleSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-secondary/35 py-24 border-y border-border select-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white/80 via-transparent to-transparent opacity-60" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -top-32 left-1/4 size-96 rounded-full bg-primary/5 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -bottom-32 right-1/4 size-96 rounded-full bg-gold/5 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						variant: "fade-up",
						className: "text-center max-w-3xl mx-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-sky-border mb-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-6 h-0.5 bg-sky-border inline-block" }),
									"Admission Process",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-6 h-0.5 bg-sky-border inline-block" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-3xl font-extrabold tracking-tight text-primary sm:text-4xl lg:text-5xl",
								children: [
									"Simple 3-Step Pathway to Join",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "relative inline-block",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "italic text-gold",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
											className: "absolute -bottom-2.5 left-0 w-full h-3.5 text-gold overflow-visible",
											viewBox: "0 0 320 12",
											fill: "none",
											preserveAspectRatio: "none",
											"aria-hidden": "true",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
												d: "M3 8.5C65 2.5 190 2 317 7.5",
												stroke: "currentColor",
												strokeWidth: "4.5",
												strokeLinecap: "round"
											})
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-base sm:text-lg text-muted-foreground font-medium",
								children: "We make the transition seamless and supportive for both parents and students. Every piece of your child's academic roadmap connects effortlessly."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-14 hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							variant: "fade-up",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative mx-auto w-full max-w-[1040px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									viewBox: "0 0 1040 680",
									className: "w-full h-auto overflow-visible select-none",
									"aria-label": "3-Step Admission Process Jigsaw Puzzle Infographic",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("filter", {
											id: "puzzleShadow",
											x: "-15%",
											y: "-15%",
											width: "130%",
											height: "130%",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feDropShadow", {
												dx: "0",
												dy: "12",
												stdDeviation: "16",
												floodColor: "#0f172a",
												floodOpacity: "0.14"
											})
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
											className: "transition-all duration-300",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
													cx: "310",
													cy: "270",
													r: "5",
													fill: "#1b365d"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
													d: "M 310 270 L 75 270 L 75 75 L 115 75",
													fill: "none",
													stroke: "#1b365d",
													strokeWidth: "2.5",
													strokeLinecap: "round"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
													cx: "115",
													cy: "75",
													r: "5",
													fill: "#1b365d"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
											className: "transition-all duration-300",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
													cx: "630",
													cy: "180",
													r: "5",
													fill: "#d97706"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
													d: "M 630 180 L 630 80 L 740 80",
													fill: "none",
													stroke: "#d97706",
													strokeWidth: "2.5",
													strokeLinecap: "round"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
													cx: "740",
													cy: "80",
													r: "5",
													fill: "#d97706"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
											className: "transition-all duration-300",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
													cx: "520",
													cy: "584",
													r: "5",
													fill: "#0284c7"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
													d: "M 520 584 L 520 615 L 600 615",
													fill: "none",
													stroke: "#0284c7",
													strokeWidth: "2.5",
													strokeLinecap: "round"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
													cx: "600",
													cy: "615",
													r: "5",
													fill: "#0284c7"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
											className: "cursor-pointer transition-transform duration-300 hover:scale-[1.02] origin-center",
											filter: "url(#puzzleShadow)",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
													d: `
                      M 310 180
                      L 390 180
                      C 390 175, 386 156, 410 156
                      C 434 156, 430 175, 430 180
                      L 510 180

                      L 510 250
                      C 515 250, 534 246, 534 270
                      C 534 294, 515 290, 510 290
                      L 510 360

                      L 430 360
                      C 430 365, 434 384, 410 384
                      C 386 384, 390 365, 390 360
                      L 310 360

                      L 310 290
                      C 315 290, 334 294, 334 270
                      C 334 246, 315 250, 310 250
                      L 310 180
                      Z
                    `,
													fill: "#1b365d",
													stroke: "#ffffff",
													strokeWidth: "3.5",
													strokeLinejoin: "round"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: "420",
													y: "262",
													textAnchor: "middle",
													fill: "#fbbf24",
													fontSize: "11",
													fontWeight: "800",
													letterSpacing: "0.18em",
													className: "select-none uppercase",
													children: "STEP 01"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: "420",
													y: "288",
													textAnchor: "middle",
													fill: "#ffffff",
													fontSize: "15",
													fontWeight: "800",
													letterSpacing: "0.04em",
													className: "select-none uppercase font-display",
													children: "COUNSELLING"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
											className: "cursor-pointer transition-transform duration-300 hover:scale-[1.02] origin-center",
											filter: "url(#puzzleShadow)",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
													d: `
                      M 530 180
                      L 730 180

                      L 730 250
                      C 725 250, 706 246, 706 270
                      C 706 294, 725 290, 730 290
                      L 730 360

                      L 650 360
                      C 650 365, 654 384, 630 384
                      C 606 384, 610 365, 610 360
                      L 530 360

                      L 530 290
                      C 535 290, 554 294, 554 270
                      C 554 246, 535 250, 530 250
                      L 530 180
                      Z
                    `,
													fill: "#d97706",
													stroke: "#ffffff",
													strokeWidth: "3.5",
													strokeLinejoin: "round"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: "630",
													y: "262",
													textAnchor: "middle",
													fill: "#fef3c7",
													fontSize: "11",
													fontWeight: "800",
													letterSpacing: "0.18em",
													className: "select-none uppercase",
													children: "STEP 02"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: "630",
													y: "288",
													textAnchor: "middle",
													fill: "#ffffff",
													fontSize: "15",
													fontWeight: "800",
													letterSpacing: "0.04em",
													className: "select-none uppercase font-display",
													children: "ACESET TEST"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
											className: "cursor-pointer transition-transform duration-300 hover:scale-[1.02] origin-center",
											filter: "url(#puzzleShadow)",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
													d: `
                      M 420 380
                      L 500 380
                      C 500 385, 496 404, 520 404
                      C 544 404, 540 385, 540 380
                      L 620 380

                      L 620 450
                      C 625 450, 644 446, 644 470
                      C 644 494, 625 490, 620 490
                      L 620 560

                      L 540 560
                      C 540 565, 544 584, 520 584
                      C 496 584, 500 565, 500 560
                      L 420 560

                      L 420 490
                      C 415 490, 396 494, 396 470
                      C 396 446, 415 450, 420 450
                      L 420 380
                      Z
                    `,
													fill: "#0284c7",
													stroke: "#ffffff",
													strokeWidth: "3.5",
													strokeLinejoin: "round"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: "520",
													y: "472",
													textAnchor: "middle",
													fill: "#e0f2fe",
													fontSize: "11",
													fontWeight: "800",
													letterSpacing: "0.18em",
													className: "select-none uppercase",
													children: "STEP 03"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: "520",
													y: "498",
													textAnchor: "middle",
													fill: "#ffffff",
													fontSize: "15",
													fontWeight: "800",
													letterSpacing: "0.04em",
													className: "select-none uppercase font-display",
													children: "ENROLMENT"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("foreignObject", {
											x: "125",
											y: "52",
											width: "175",
											height: "160",
											className: "overflow-visible",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-left group pr-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
														className: "font-display font-extrabold text-xs sm:text-sm tracking-wider uppercase text-primary flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-primary" }), "Free Academic Counselling"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-2 text-xs text-muted-foreground font-medium leading-relaxed",
														children: "Meet our academic mentors along with your child. We assess their learning style, current strengths, and set clear milestones."
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-2 text-[10.5px] font-bold text-primary",
														children: "★ 1-on-1 Parent Consultation"
													})
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("foreignObject", {
											x: "755",
											y: "58",
											width: "265",
											height: "150",
											className: "overflow-visible",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-left group pl-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
														className: "font-display font-extrabold text-xs sm:text-sm tracking-wider uppercase text-gold flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-gold" }), "Appear for ACESET"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-2 text-xs text-muted-foreground font-medium leading-relaxed",
														children: "Participate in the ACE Scholarship Entrance Test to evaluate subject readiness and earn merit scholarships up to 100%*."
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-2 text-[10.5px] font-bold text-gold",
														children: "★ Up to 100% Scholarship Waiver"
													})
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("foreignObject", {
											x: "615",
											y: "560",
											width: "360",
											height: "130",
											className: "overflow-visible",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-left group pl-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
														className: "font-display font-extrabold text-xs sm:text-sm tracking-wider uppercase text-sky-border flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-sky-border" }), "Personalized Pathway Enrolment"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-2 text-xs text-muted-foreground font-medium leading-relaxed",
														children: "Choose the tailored programme (Foundation, Board Support, Math Mastery, Test Series or Language Support) with no school-timing clashes."
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-2 text-[10.5px] font-bold text-sky-border",
														children: "★ Synchronized with School Timetable"
													})
												]
											})
										})
									]
								})
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-12 space-y-6 lg:hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								variant: "fade-up",
								delay: 0,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-3xl border-2 border-primary/30 bg-card p-6 shadow-sm relative overflow-hidden",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 left-0 w-2 h-full bg-primary" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-primary/10 text-primary px-3 py-1 text-xs font-bold uppercase tracking-wider",
												children: "Step 01 · Counselling"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-full bg-primary" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-3 font-display text-lg font-bold text-primary",
											children: "Free Academic Counselling"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-xs text-muted-foreground font-medium leading-relaxed",
											children: "Meet our academic mentors along with your child. We assess their learning style, current strengths, and set clear milestones."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 rounded-xl bg-primary/5 p-2.5 text-[11px] font-bold text-primary border border-primary/10",
											children: "★ 1-on-1 Parent Consultation · Zero Obligation"
										})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								variant: "fade-up",
								delay: 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-3xl border-2 border-gold/40 bg-card p-6 shadow-sm relative overflow-hidden",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 left-0 w-2 h-full bg-gold" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-gold/15 text-gold-foreground px-3 py-1 text-xs font-bold uppercase tracking-wider",
												children: "Step 02 · Scholarship Test"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-full bg-gold" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "mt-3 font-display text-lg font-bold text-primary",
											children: [
												"Appear for ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
												"SET"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-xs text-muted-foreground font-medium leading-relaxed",
											children: "Participate in the ACE Scholarship Entrance Test to evaluate subject readiness and earn merit scholarships up to 100%*."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 rounded-xl bg-gold/10 p-2.5 text-[11px] font-bold text-gold-foreground border border-gold/20",
											children: "★ Diagnostic Aptitude Check · Up to 100% Fee Waiver"
										})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								variant: "fade-up",
								delay: 200,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-3xl border-2 border-sky-border/40 bg-card p-6 shadow-sm relative overflow-hidden",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 left-0 w-2 h-full bg-sky-border" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-sky text-sky-border px-3 py-1 text-xs font-bold uppercase tracking-wider",
												children: "Step 03 · Enrolment"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-full bg-sky-border" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-3 font-display text-lg font-bold text-primary",
											children: "Personalized Pathway Enrolment"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-xs text-muted-foreground font-medium leading-relaxed",
											children: "Choose the tailored programme (Foundation, Board Support, Math Mastery, Test Series or Language Support) with no school-timing clashes."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 rounded-xl bg-sky/40 p-2.5 text-[11px] font-bold text-primary border border-sky-border/30",
											children: "★ Flexible Batches · Synchronized with School Timetable"
										})
									]
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-14 text-center flex flex-wrap items-center justify-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#enquire",
							className: "inline-flex items-center gap-2 rounded-full bg-gold px-8 py-3.5 font-bold text-gold-foreground transition hover:-translate-y-0.5 hover:shadow-lg",
							children: ["Enquire Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: contact.whatsappHref,
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex items-center gap-2 rounded-full border-2 border-primary/20 bg-card px-7 py-3.5 font-bold text-primary transition hover:border-gold hover:text-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4 text-emerald-600" }), " WhatsApp Admissions Desk"]
						})]
					})
				]
			})
		]
	});
}
var Route$6 = createFileRoute("/admissions")({
	head: () => ({ meta: [
		{ title: "Join ACE | Why Parents Choose ACE Education, Hubballi" },
		{
			name: "description",
			content: "Discover why parents in Hubballi choose ACE for Classes 8, 9 & 10. Strong conceptual foundations, experiential learning, individual mentoring, and academic excellence."
		},
		{
			property: "og:title",
			content: "Join ACE — Why Parents Choose ACE Education"
		},
		{
			property: "og:description",
			content: "From Concepts to Confidence. Learn why 500+ students and parents trust ACE for ICSE, CBSE and State Board excellence."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: AdmissionsPage
});
function AdmissionsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "relative overflow-hidden bg-navy-pattern text-navy-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace grid items-center gap-12 py-16 md:py-24 lg:grid-cols-[1.1fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fade-up",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "inline-flex items-center gap-2 rounded-full bg-gold px-4 py-1.5 text-xs sm:text-sm font-bold text-gold-foreground shadow-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
									className: "size-4",
									"aria-hidden": true
								}),
								" Admissions Open · Academic Year ",
								contact.admissionYear
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-6 text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-[1.08] tracking-tight",
							children: [
								"Where Curiosity Becomes Clarity.",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative inline-block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "italic text-gold",
										children: "Confidence Follows."
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										className: "absolute -bottom-2.5 left-0 w-full h-3.5 text-gold overflow-visible",
										viewBox: "0 0 320 12",
										fill: "none",
										preserveAspectRatio: "none",
										"aria-hidden": "true",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: "M3 8.5C65 2.5 190 2 317 7.5",
											stroke: "currentColor",
											strokeWidth: "4.5",
											strokeLinecap: "round"
										})
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 max-w-xl text-base sm:text-lg leading-relaxed opacity-90 font-medium",
							children: [
								"At ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }),
								" Education, Hubballi, we believe every child possesses the potential to achieve extraordinary things when guided with purposeful mentorship, conceptual clarity and an inspiring learning environment."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-2.5 text-xs font-bold text-gold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-white/10 px-3 py-1.5 border border-white/15",
									children: "★ 500+ Students Guided"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-white/10 px-3 py-1.5 border border-white/15",
									children: "★ Classes 8, 9 & 10"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-white/10 px-3 py-1.5 border border-white/15",
									children: "★ ICSE · CBSE · State Board"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-white/10 px-3 py-1.5 border border-white/15",
									children: "★ Up to 100% Scholarship"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#enquire",
								className: "inline-flex items-center gap-2 rounded-full bg-gold px-7 py-3.5 font-bold text-gold-foreground transition hover:-translate-y-0.5 hover:shadow-lg",
								children: ["Enquire Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "size-4",
									"aria-hidden": true
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: contact.whatsappHref,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-2 rounded-full border-2 border-navy-foreground/40 px-7 py-3.5 font-bold transition hover:border-gold hover:text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "size-4 text-emerald-400",
									"aria-hidden": true
								}), " WhatsApp Admissions"]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative fade-up [animation-delay:150ms]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden rounded-3xl border-4 border-gold/70 shadow-lift",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: study_illustration_default,
								alt: "Students studying science and mathematics collaboratively at ACE Education Hubballi",
								width: 1280,
								height: 960,
								className: "size-full object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-navy/80 via-transparent to-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute bottom-5 left-5 right-5 text-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-widest text-gold font-bold",
									children: "The ACE Learning Environment"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm sm:text-base font-semibold mt-1",
									children: "“We don't just teach students what to learn. We inspire them to understand, explore, question and grow.”"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute -bottom-5 -left-4 sm:left-4 rounded-2xl bg-card p-4 text-card-foreground shadow-lift border border-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-11 place-items-center rounded-xl bg-gold text-gold-foreground font-black text-xl",
								children: "✓"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-lg font-bold text-primary",
								children: "From Concepts to Confidence"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground font-medium",
								children: "Hubballi's Dedicated Academic Hub"
							})] })]
						})
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
			variant: "fade-in",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-b bg-card py-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-ace flex flex-wrap items-center justify-between gap-4 text-xs sm:text-sm font-semibold text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-gold/15 px-3 py-1 text-gold-foreground font-bold",
							children: "Target Classes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold",
							children: "Class 8 · Class 9 · Class 10"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Supported Boards:"
						}), boards.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-sky-border/60 bg-sky/40 px-3 py-0.5 text-xs font-bold",
							children: b
						}, b))]
					})]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhyParentsTrustRadialSection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EducationalPhilosophyWaveSection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommitmentsInfographicSection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdmissionPathwayPuzzleSection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-ace grid gap-10 py-20 lg:grid-cols-[1fr_1.5fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				variant: "slide-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Parent FAQ",
					title: "Questions Parents Ask Before Joining",
					intro: "We understand that choosing the right academic partner for your child is an important decision. If you have any additional questions, call us directly on +91 91484 86661."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 rounded-2xl border-2 border-gold/40 bg-sky/50 p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-display font-bold text-primary",
							children: "Need in-person guidance?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted-foreground leading-relaxed",
							children: "Visit us at Lakeside Commercial Complex, Opp. Tolankere, Hubballi for a direct consultation with our academic directors."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: contact.phoneHref,
							className: "mt-4 inline-flex items-center gap-2 font-bold text-xs text-primary hover:text-gold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3.5" }),
								" Call ",
								contact.phoneDisplay
							]
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				variant: "slide-right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactSection, { title: `Enquire for Admission (${contact.admissionYear})` })
	] });
}
var $$splitComponentImporter$5 = () => import("./career-CJHRC8o2.mjs");
var Route$5 = createFileRoute("/career")({
	head: () => ({ meta: [{ title: "Career | ACE – Education Redefined, Hubballi" }, {
		name: "description",
		content: "Career opportunities at ACE coaching institute, Hubballi."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./contact-Bp2L7blW.mjs");
var Route$4 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: "Connect With Us | ACE – Education Redefined, Hubballi" }, {
		name: "description",
		content: "Get in touch with ACE coaching institute, Hubballi."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./courses-Bzw2G1j0.mjs");
var Route$3 = createFileRoute("/courses")({
	head: () => ({ meta: [{ title: "Explore Programs | ACE – Education Redefined, Hubballi" }, {
		name: "description",
		content: "Foundation Programme & Board Exam Support for Classes 8, 9 & 10. Language support, Test Series and ACESET scholarship entrance exam at ACE, Hubballi."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./home-DUWqF6Db.mjs");
var Route$2 = createFileRoute("/home")({
	head: () => ({ meta: [{ title: "ACE Experience | ACE – Education Redefined, Hubballi" }, {
		name: "description",
		content: "ACE Education, Hubballi — From Concepts to Confidence. Programmes for Classes 8, 9 & 10. Established in 2022 | 500+ Students | Academic Excellence & Beyond Classroom Learning."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./programs-6kXm53Eu.mjs");
var Route$1 = createFileRoute("/programs")({
	head: () => ({ meta: [
		{ title: "Programs for Classes VIII–X | ACE Education, Hubballi" },
		{
			name: "description",
			content: "Bridge Course, Foundation (PCMB & Reasoning), Board Support, Curated Test Series, Math Mastery and Kannada & Hindi support at ACE, Hubballi."
		},
		{
			property: "og:title",
			content: "ACE Programs — Foundation, Board Support & Math Mastery"
		},
		{
			property: "og:description",
			content: "Six programs for Classes VIII, IX & X across ICSE, CBSE and State Board."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./results-CUJKJn9w.mjs");
var Route = createFileRoute("/results")({
	head: () => ({ meta: [{ title: "Our Achievers | ACE – Education Redefined, Hubballi" }, {
		name: "description",
		content: `Meet ACE's ${contact.achieversYear} achievers — NEET, IIT JEE and board exam toppers from Hubballi.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$8.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$9
	}),
	AboutRoute: Route$7.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => Route$9
	}),
	AdmissionsRoute: Route$6.update({
		id: "/admissions",
		path: "/admissions",
		getParentRoute: () => Route$9
	}),
	CareerRoute: Route$5.update({
		id: "/career",
		path: "/career",
		getParentRoute: () => Route$9
	}),
	ContactRoute: Route$4.update({
		id: "/contact",
		path: "/contact",
		getParentRoute: () => Route$9
	}),
	CoursesRoute: Route$3.update({
		id: "/courses",
		path: "/courses",
		getParentRoute: () => Route$9
	}),
	HomeRoute: Route$2.update({
		id: "/home",
		path: "/home",
		getParentRoute: () => Route$9
	}),
	ProgramsRoute: Route$1.update({
		id: "/programs",
		path: "/programs",
		getParentRoute: () => Route$9
	}),
	ResultsRoute: Route.update({
		id: "/results",
		path: "/results",
		getParentRoute: () => Route$9
	})
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
