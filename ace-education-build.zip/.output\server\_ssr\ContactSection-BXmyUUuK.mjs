import { i as __toESM } from "../_runtime.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-D7Yke8xV.mjs";
import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { _ as require_react, a as AccordionTrigger$1, g as require_jsx_runtime, i as AccordionItem$1, n as AccordionContent$1, r as AccordionHeader, t as Accordion$1 } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { A as ClipboardCheck, C as Languages, F as Calculator, L as BookOpenCheck, M as CircleAlert, N as ChevronDown, O as FileCheckCorner, R as ArrowRight, S as Layers, b as Lock, c as Send, d as RefreshCw, f as Printer, h as Minus, j as CircleCheck, m as Phone, s as ShieldCheck, u as Rocket, v as MapPin, y as Mail } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as objectType, r as stringType, t as enumType } from "../_libs/zod.mjs";
import { n as Nt, t as $t } from "../_libs/input-otp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ContactSection-BXmyUUuK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var contact = {
	brand: "ACE – Education Redefined",
	tagline: "From Concepts to Confidence",
	phoneDisplay: "+91 91484 86661",
	phoneHref: "tel:+919148486661",
	whatsappHref: "https://wa.me/919148486661",
	website: "www.aceEduHub.com",
	websiteHref: "https://www.aceEduHub.com",
	instagram: "ace_edu_hubballi",
	instagramHref: "https://www.instagram.com/ace_edu_hubballi/",
	facebook: "ACE - Education Redefined",
	addressLines: [
		"Lakeside Commercial Complex, 2nd Floor,",
		"Opp. Tolankere, Lakshmi Nagar,",
		"Hubballi – 580030"
	],
	mapsHref: "https://www.google.com/maps/search/?api=1&query=Lakeside+Commercial+Complex+Lakshmi+Nagar+Hubballi+580030",
	admissionYear: "2027–28",
	achieversYear: "2025–26"
};
var boards = [
	"ICSE",
	"CBSE",
	"State Board"
];
var programs = [
	{
		id: "bridge",
		name: "Bridge Course",
		summary: "Enhance knowledge, skill & curriculum gaps to strengthen concepts."
	},
	{
		id: "foundation",
		name: "Foundation",
		summary: "School learning to higher competitive excellence.",
		highlight: "PCMB & Reasoning"
	},
	{
		id: "board",
		name: "Board Support",
		summary: "Comprehensive NCERT-aligned board preparation.",
		highlight: "ICSE · CBSE · State"
	},
	{
		id: "tests",
		name: "Curated Test Series",
		summary: "Structured assessment with results & remedial support."
	},
	{
		id: "math",
		name: "Math Mastery",
		summary: "An approach to build deep, long-term conceptual learning.",
		highlight: "Morning classes"
	},
	{
		id: "language",
		name: "Language Support",
		summary: "Dedicated support for Kannada & Hindi.",
		highlight: "ಕ  ·  ह"
	}
];
var achieverGroups = [
	{
		id: "neet-jee",
		title: "NEET / IIT JEE",
		students: [
			{
				name: "Sanjana Benakatti",
				score: "525",
				scoreSub: "/720",
				institution: "SNMC, Bagalkot",
				photo: "/images/achievers/sanjana-benakatti.webp"
			},
			{
				name: "Khalid Mirji",
				score: "488",
				scoreSub: "/720",
				institution: "SNMC, Bagalkot",
				photo: "/images/achievers/khalid-mirji.webp"
			},
			{
				name: "Niranjan K",
				score: "AIR* 1153",
				institution: "IIT Mumbai",
				photo: "/images/achievers/niranjan-k.webp"
			},
			{
				name: "Mohammad Ayaan",
				score: "98.03",
				scoreSub: "%ile",
				institution: "MSRIT, Bangalore",
				photo: "/images/achievers/mohammad-ayaan.webp"
			}
		]
	},
	{
		id: "class-x",
		title: "Class X",
		students: [
			{
				name: "Aadhya Hiremath",
				score: "95.2%",
				tag: "ICSE",
				photo: "/images/achievers/aadhya-hiremath.webp"
			},
			{
				name: "Tejas Onimani",
				score: "97%",
				tag: "STATE",
				photo: "/images/achievers/tejas-onimani.webp"
			},
			{
				name: "Rajat kulkarni",
				score: "91.8%",
				tag: "CBSE",
				photo: "/images/achievers/rajat-kulkarni.webp"
			},
			{
				name: "Prasanna Totad",
				score: "91.2%",
				tag: "CBSE",
				photo: "/images/achievers/prasanna-totad.webp"
			}
		]
	},
	{
		id: "class-ix",
		title: "Class IX",
		students: [{
			name: "Sharan Tugalad",
			score: "96%",
			tag: "CBSE",
			photo: "/images/achievers/sharan-tugalad.webp"
		}, {
			name: "Shalini Shettar",
			score: "82%",
			tag: "CBSE",
			photo: "/images/achievers/shalini-shettar.webp"
		}]
	},
	{
		id: "class-viii",
		title: "Class VIII",
		students: [{
			name: "Amogh Mantur",
			score: "85%",
			tag: "CBSE",
			photo: "/images/achievers/amogh-mantur.webp"
		}]
	}
];
var faqs = [
	{
		q: "Which classes does ACE teach?",
		a: "ACE runs programs for students of Classes VII, VIII, IX and X."
	},
	{
		q: "Which boards do you support?",
		a: "We support students from ICSE, CBSE and State Board schools."
	},
	{
		q: "Are admissions open?",
		a: "Yes — admissions are open for Academic Year 2027–28. Send an enquiry or call +91 91484 86661 to know more."
	},
	{
		q: "What programs are offered?",
		a: "Bridge Course, Foundation (PCMB & Reasoning), Board Support, Curated Test Series, Math Mastery and Language Support (Kannada & Hindi)."
	},
	{
		q: "Do you prepare students for competitive exams?",
		a: "Our Foundation program takes students from school learning to higher competitive excellence, covering Physics, Chemistry, Maths, Biology and Reasoning."
	},
	{
		q: "When are Math Mastery classes held?",
		a: "Math Mastery runs as morning classes. Please call us for the current batch timings."
	},
	{
		q: "Where is ACE located?",
		a: "Lakeside Commercial Complex, 2nd Floor, Opp. Tolankere, Lakshmi Nagar, Hubballi – 580030."
	}
];
/** Renders an image, swapping to `fallback` if it fails (including failures before hydration). */
function SafeImage({ fallback, onError, ...img }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (el && el.complete && el.naturalWidth === 0) setFailed(true);
	}, [img.src]);
	if (failed || !img.src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: fallback });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		ref,
		...img,
		onError: (e) => {
			setFailed(true);
			onError?.(e);
		}
	});
}
function LogoFallback({ className = "", onDark = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `inline-flex items-baseline gap-2 font-display leading-none ${className}`,
		role: "img",
		"aria-label": "ACE – Education Redefined",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `text-3xl font-bold ${onDark ? "text-gold" : "text-primary"}`,
			children: "ACE"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `text-[0.65rem] font-semibold uppercase tracking-widest ${onDark ? "opacity-80" : "text-muted-foreground"}`,
			children: "Education Redefined"
		})]
	});
}
function initials(name) {
	return name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join("");
}
/**
* Renders the brand name "ACE" in uppercase standard brand styling.
*/
function AceWord({ dark, className = "", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-block font-bold tracking-tight select-none ${className}`,
		...props,
		children: "ACE"
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var Accordion = Accordion$1;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionItem$1, {
	ref,
	className: cn("border-b", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionHeader, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionTrigger$1, {
		ref,
		className: cn("flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = AccordionTrigger$1.displayName;
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent$1, {
	ref,
	className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-4 pt-0", className),
		children
	})
}));
AccordionContent.displayName = AccordionContent$1.displayName;
function Eyebrow({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-bold uppercase tracking-[0.2em] text-sky-border",
		children
	});
}
function SectionHeading({ eyebrow, title, intro }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: eyebrow }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 text-3xl font-semibold text-primary md:text-4xl",
				children: title
			}),
			intro && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted-foreground",
				children: intro
			})
		]
	});
}
var icons = {
	bridge: Layers,
	foundation: Rocket,
	board: BookOpenCheck,
	tests: ClipboardCheck,
	math: Calculator,
	language: Languages
};
function ProgramCard({ program, index }) {
	const Icon = icons[program.id] ?? Layers;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group relative flex h-full flex-col rounded-2xl border-2 border-sky-border/40 bg-sky p-6 transition duration-300 hover:-translate-y-1 hover:border-sky-border hover:shadow-lift",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-12 place-items-center rounded-xl bg-primary text-primary-foreground transition group-hover:bg-gold group-hover:text-gold-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-6",
						"aria-hidden": true
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-3xl text-sky-border/30",
					children: String(index + 1).padStart(2, "0")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-5 text-xl font-semibold text-primary",
				children: program.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 flex-1 text-sm text-muted-foreground",
				children: program.summary
			}),
			program.highlight && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 inline-flex w-fit rounded-full bg-gold px-3 py-1 text-xs font-bold text-gold-foreground",
				children: program.highlight
			})
		]
	});
}
function AchieverCard({ a }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "group overflow-hidden rounded-2xl border bg-card shadow-card transition hover:-translate-y-1 hover:shadow-lift",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-[4/5] overflow-hidden bg-sky",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafeImage, {
				src: a.photo,
				alt: `Photo of ${a.name}`,
				loading: "lazy",
				width: 400,
				height: 500,
				className: "h-full w-full object-cover object-top transition duration-500 group-hover:scale-105",
				fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					role: "img",
					"aria-label": `Photo of ${a.name}`,
					className: "flex h-full w-full items-center justify-center bg-navy-pattern",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-5xl font-bold text-gold",
						children: initials(a.name)
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute right-3 top-3 rounded-xl bg-gold px-3 py-2 text-center font-display leading-none text-gold-foreground shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-lg font-bold",
					children: a.score
				}), a.scoreSub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs font-semibold",
					children: a.scoreSub
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
			className: "p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-bold text-primary",
				children: a.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: a.institution ?? a.tag
			})]
		})]
	});
}
function Faq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
		type: "single",
		collapsible: true,
		className: "divide-y rounded-2xl border bg-card px-6 shadow-card",
		children: faqs.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
			value: `f${i}`,
			className: "border-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
				className: "py-5 text-left text-base font-semibold text-primary",
				children: f.q
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
				className: "text-muted-foreground",
				children: f.a
			})]
		}, f.q))
	});
}
function Placeholder({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border-2 border-dashed border-sky-border/40 bg-sky p-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-bold uppercase tracking-widest text-sky-border",
				children: "Content coming soon"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 text-2xl font-semibold text-primary",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-lg text-sm text-muted-foreground",
				children
			})
		]
	});
}
var enquirySchema = objectType({
	studentName: stringType().trim().min(2, "Please enter the student's name").max(80, "Name is too long"),
	parentName: stringType().trim().min(2, "Please enter the parent's name").max(80, "Name is too long"),
	email: stringType().trim().email("Please enter a valid email address").optional(),
	phone: stringType().trim().transform((v) => v.replace(/[\s-]/g, "").replace(/^(\+91|0)/, "")).refine((v) => /^[6-9]\d{9}$/.test(v), "Enter a valid 10-digit Indian mobile number"),
	studentClass: enumType([
		"Class VII",
		"Class VIII",
		"Class IX",
		"Class X",
		"Class VII (7th)",
		"Class VIII (8th)",
		"Class IX (9th)",
		"Class X (10th)",
		"7th",
		"8th",
		"9th",
		"10th"
	], { errorMap: () => ({ message: "Choose a class" }) }),
	board: enumType([
		"ICSE",
		"CBSE",
		"State Board"
	], { errorMap: () => ({ message: "Choose a board" }) }),
	program: stringType().min(1, "Choose a program"),
	notes: stringType().optional()
});
var InputOTP = import_react.forwardRef(({ className, containerClassName, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)($t, {
	ref,
	containerClassName: cn("flex items-center gap-2 has-[:disabled]:opacity-50", containerClassName),
	className: cn("disabled:cursor-not-allowed", className),
	...props
}));
InputOTP.displayName = "InputOTP";
var InputOTPGroup = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex items-center", className),
	...props
}));
InputOTPGroup.displayName = "InputOTPGroup";
var InputOTPSlot = import_react.forwardRef(({ index, className, ...props }, ref) => {
	const { char, hasFakeCaret, isActive } = import_react.useContext(Nt).slots[index] ?? {
		char: null,
		hasFakeCaret: false,
		isActive: false
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: cn("relative flex h-9 w-9 items-center justify-center border-y border-r border-input text-sm shadow-sm transition-all first:rounded-l-md first:border-l last:rounded-r-md", isActive && "z-10 ring-1 ring-ring", className),
		...props,
		children: [char, hasFakeCaret && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-0 flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-px animate-caret-blink bg-foreground duration-1000" })
		})]
	});
});
InputOTPSlot.displayName = "InputOTPSlot";
var InputOTPSeparator = import_react.forwardRef(({ ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	role: "separator",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
}));
InputOTPSeparator.displayName = "InputOTPSeparator";
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/**
* Loads .env directly from the filesystem on demand.
* This guarantees freshly entered credentials work immediately without needing to restart the Vite server.
*/
/**
* Retrieves the real transparent ACE logo as an inline attachment (CID).
* This allows all major email clients (Gmail, Apple Mail, Outlook) to display the logo immediately.
*/
/**
* Creates or retrieves the mail delivery mechanism.
* Dynamically imports nodemailer on server-side to avoid bundling node internals into client.
*/
/**
* Server Function: Dispatches OTP verification code to applicant's email address.
* Features the real transparent ACE logo and smooth CSS keyframe animations.
*/
var sendOtpServerFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("a4a06ffed0c1ec526f7a848ed7624d0fbea05949c8868155798d82dbb6641c52"));
/**
* Server Function: Dispatches official notification to admissions office and parent.
* Features real logo and styled confirmation receipt.
*/
var sendEnquiryServerFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("262f528896f581df4ad92ee8011e704e16ec47a2b17f4cdfd16959e3f2159c63"));
var fieldClass = "mt-1.5 w-full rounded-xl border border-input bg-card px-4 py-3 text-sm outline-none transition focus:border-sky-border focus:ring-2 focus:ring-ring/30 aria-[invalid=true]:border-destructive disabled:opacity-60 disabled:cursor-not-allowed";
function EnquiryForm({ defaultProgram = "" }) {
	const [email, setEmail] = (0, import_react.useState)("");
	const [emailInput, setEmailInput] = (0, import_react.useState)("");
	const [otpSent, setOtpSent] = (0, import_react.useState)(false);
	const [generatedOtp, setGeneratedOtp] = (0, import_react.useState)("");
	const [enteredOtp, setEnteredOtp] = (0, import_react.useState)("");
	const [isVerified, setIsVerified] = (0, import_react.useState)(false);
	const [otpError, setOtpError] = (0, import_react.useState)(null);
	const [emailError, setEmailError] = (0, import_react.useState)(null);
	const [resendTimer, setResendTimer] = (0, import_react.useState)(0);
	const [isSending, setIsSending] = (0, import_react.useState)(false);
	const [isRealDelivery, setIsRealDelivery] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const [submission, setSubmission] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (resendTimer <= 0) return;
		const interval = setInterval(() => {
			setResendTimer((t) => t - 1);
		}, 1e3);
		return () => clearInterval(interval);
	}, [resendTimer]);
	async function handleSendOtp() {
		setEmailError(null);
		setOtpError(null);
		if (!emailInput || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.trim())) {
			setEmailError("Please enter a valid email address");
			return;
		}
		const cleanEmail = emailInput.trim();
		setIsSending(true);
		try {
			const code = String(Math.floor(1e5 + Math.random() * 9e5));
			setGeneratedOtp(code);
			setEmail(cleanEmail);
			const res = await sendOtpServerFn({ data: {
				email: cleanEmail,
				otp: code
			} });
			if (res && "error" in res && res.error) {
				setEmailError(res.error);
				return;
			}
			setOtpSent(true);
			setResendTimer(45);
			setIsRealDelivery(Boolean(res?.delivered));
		} catch {
			setEmailError("Unable to connect to email service. Please try again or contact the admissions desk.");
		} finally {
			setIsSending(false);
		}
	}
	function handleVerifyOtp() {
		setOtpError(null);
		if (!enteredOtp || enteredOtp.length !== 6) {
			setOtpError("Please enter the complete 6-digit OTP");
			return;
		}
		if (enteredOtp === generatedOtp) {
			setIsVerified(true);
			setOtpError(null);
		} else setOtpError("Incorrect OTP code. Please enter the code dispatched to your email.");
	}
	async function onSubmit(e) {
		e.preventDefault();
		if (!isVerified) {
			setEmailError("Please verify your email with OTP before submitting.");
			return;
		}
		const formData = new FormData(e.currentTarget);
		const dataWithEmail = {
			...Object.fromEntries(formData),
			email
		};
		const res = enquirySchema.safeParse(dataWithEmail);
		if (!res.success) {
			const errs = {};
			for (const issue of res.error.issues) errs[String(issue.path[0])] ??= issue.message;
			setErrors(errs);
			return;
		}
		setErrors({});
		setIsSubmitting(true);
		try {
			const result = {
				refId: `ACE-${(/* @__PURE__ */ new Date()).getFullYear()}-${Math.floor(1e5 + Math.random() * 9e5)}`,
				studentName: res.data.studentName,
				parentName: res.data.parentName,
				email,
				phone: res.data.phone,
				studentClass: res.data.studentClass,
				board: res.data.board,
				program: res.data.program,
				submittedAt: (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
					day: "numeric",
					month: "short",
					year: "numeric",
					hour: "2-digit",
					minute: "2-digit"
				})
			};
			try {
				const existing = JSON.parse(localStorage.getItem("ace_enquiries") || "[]");
				existing.push(result);
				localStorage.setItem("ace_enquiries", JSON.stringify(existing));
			} catch {}
			await sendEnquiryServerFn({ data: result });
			setSubmission(result);
		} catch (err) {
			console.error("Submission failed:", err);
		} finally {
			setIsSubmitting(false);
		}
	}
	if (submission) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "status",
		className: "rounded-3xl border-2 border-emerald-500/30 bg-card p-8 text-center shadow-lift",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto flex size-16 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-600",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
					className: "size-10",
					"aria-hidden": true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-4 inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold uppercase tracking-wider text-emerald-800",
				children: "Official Admission Enquiry Registered"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-display text-3xl font-bold text-primary",
				children: "Enquiry Submitted Successfully!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mx-auto mt-2 max-w-md text-sm text-muted-foreground",
				children: [
					"Thank you, ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: submission.parentName }),
					". Your enquiry for",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: submission.studentName }),
					" has been registered with the admissions desk."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-2xl border bg-secondary/50 p-5 text-left text-sm space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b pb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
							children: "Reference ID"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono font-bold text-primary",
							children: submission.refId
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Student Name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-primary",
							children: submission.studentName
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Verified Email"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-primary",
							children: submission.email
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Contact Mobile"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold text-primary",
							children: ["+91 ", submission.phone]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Class & Board"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold text-primary",
							children: [
								submission.studentClass,
								" · ",
								submission.board
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Program"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-primary",
							children: submission.program
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs text-muted-foreground",
				children: [
					"Our admissions counsellor will contact you within 24 hours. A copy of this enquiry has also been dispatched to",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-primary",
						children: submission.email
					}),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap justify-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => window.print(),
						className: "inline-flex items-center gap-2 rounded-full border-2 border-primary/20 bg-secondary px-5 py-2.5 text-xs font-bold text-primary transition hover:border-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-3.5" }), " Print Receipt"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: contact.phoneHref,
						className: "inline-flex items-center gap-2 rounded-full bg-primary px-6 py-2.5 text-xs font-bold text-primary-foreground transition hover:opacity-95",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "size-3.5",
								"aria-hidden": true
							}),
							" Call Admissions (",
							contact.phoneDisplay,
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: contact.whatsappHref,
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex items-center gap-2 rounded-full border-2 border-primary px-6 py-2.5 text-xs font-bold text-primary transition hover:bg-secondary",
						children: "WhatsApp Admissions"
					})
				]
			})
		]
	});
	const err = (k) => errors[k] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		id: `${k}-err`,
		className: "mt-1 text-xs font-medium text-destructive",
		children: errors[k]
	});
	const aria = (k) => ({
		"aria-invalid": !!errors[k],
		"aria-describedby": errors[k] ? `${k}-err` : void 0
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border-2 border-sky-border/40 bg-card p-6 shadow-card md:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b pb-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5 rounded-full bg-sky px-3 py-1 text-xs font-bold text-primary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-sky-border" }), " Official Enquiry Form"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-semibold text-muted-foreground",
							children: ["Academic Year ", contact.admissionYear]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-2 text-xl font-bold text-primary",
						children: "Begin Your Admission Process"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Step 1: Verify your email with a 6-digit OTP to unlock the admission enquiry details."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-2xl border-2 border-dashed border-sky-border/50 bg-sky/40 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-bold text-primary flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4 text-sky-border" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Parent / Student Email Address" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-destructive",
								children: "*"
							})
						]
					}), isVerified && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-bold text-emerald-800",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), " Verified"]
					})]
				}), !isVerified ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								disabled: otpSent,
								value: emailInput,
								onChange: (e) => setEmailInput(e.target.value),
								placeholder: "Enter your email address (e.g. name@example.com)",
								className: fieldClass
							}), !otpSent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: handleSendOtp,
								disabled: isSending,
								className: "mt-1.5 whitespace-nowrap rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90 disabled:opacity-50",
								children: isSending ? "Sending OTP..." : "Send OTP"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setOtpSent(false);
									setEnteredOtp("");
									setOtpError(null);
								},
								className: "mt-1.5 whitespace-nowrap rounded-xl border border-input bg-card px-4 py-3 text-xs font-semibold text-muted-foreground hover:bg-secondary",
								children: "Change Email"
							})]
						}),
						emailError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium text-destructive",
							children: emailError
						}),
						otpSent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-sky-border/50 bg-card p-4 transition-all",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-3 rounded-lg bg-emerald-50 p-3.5 text-xs text-emerald-900 border border-emerald-200",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4 shrink-0 mt-0.5 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold",
										children: "Verification code dispatched to your email!"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-0.5 leading-relaxed",
										children: [
											"We have sent a 6-digit verification code to ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: email }),
											". Please check your inbox (including Promotions or Spam) and enter the code below to proceed."
										]
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex flex-col items-center gap-3 sm:flex-row sm:justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-xs font-semibold text-muted-foreground block mb-1.5",
										children: "Enter 6-Digit Verification Code"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputOTP, {
										maxLength: 6,
										value: enteredOtp,
										onChange: setEnteredOtp,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InputOTPGroup, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputOTPSlot, { index: 0 }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputOTPSlot, { index: 1 }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputOTPSlot, { index: 2 }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputOTPSlot, { index: 3 }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputOTPSlot, { index: 4 }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputOTPSlot, { index: 5 })
										] })
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: handleVerifyOtp,
											className: "inline-flex items-center gap-1.5 rounded-xl bg-gold px-5 py-2.5 text-sm font-bold text-gold-foreground transition hover:-translate-y-0.5 shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }), " Verify Code"]
										}), resendTimer > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-medium text-muted-foreground",
											children: [
												"Resend in ",
												resendTimer,
												"s"
											]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: handleSendOtp,
											className: "inline-flex items-center gap-1 text-xs font-semibold text-primary underline",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3" }), " Resend Code"]
										})]
									})]
								}),
								otpError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs font-medium text-destructive flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-3.5" }),
										" ",
										otpError
									]
								})
							]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center justify-between rounded-xl bg-emerald-50 px-4 py-3 border border-emerald-200 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-semibold text-emerald-900",
						children: ["Verified: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: email
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setIsVerified(false);
							setOtpSent(false);
							setEnteredOtp("");
						},
						className: "text-xs font-bold text-emerald-800 underline hover:text-emerald-900",
						children: "Change"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				noValidate: true,
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [!isVerified && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-0 z-10 flex flex-col items-center justify-center rounded-2xl bg-card/85 backdrop-blur-[2px] p-6 text-center border-2 border-dashed border-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-12 place-items-center rounded-2xl bg-secondary text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-6 text-sky-border" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "mt-3 font-display text-base font-bold text-primary",
								children: "Verify Email to Unlock Admission Form"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 max-w-sm text-xs text-muted-foreground",
								children: "Please enter your email address above and verify the 6-digit OTP code. All subsequent admission details will unlock immediately."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `grid gap-4 sm:grid-cols-2 ${!isVerified ? "pointer-events-none opacity-40" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-semibold text-primary",
								children: [
									"Student Full Name ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-destructive",
										children: "*"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										name: "studentName",
										autoComplete: "off",
										placeholder: "e.g. Rahul Patil",
										className: fieldClass,
										...aria("studentName")
									}),
									err("studentName")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-semibold text-primary",
								children: [
									"Parent / Guardian Name ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-destructive",
										children: "*"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										name: "parentName",
										autoComplete: "name",
										placeholder: "e.g. Suresh Patil",
										className: fieldClass,
										...aria("parentName")
									}),
									err("parentName")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-semibold text-primary sm:col-span-2",
								children: [
									"Primary Mobile Number (WhatsApp enabled) ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-destructive",
										children: "*"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative mt-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute left-4 top-3.5 text-sm font-bold text-muted-foreground",
											children: "+91"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "phone",
											type: "tel",
											inputMode: "tel",
											autoComplete: "tel",
											placeholder: "98765 43210",
											className: `${fieldClass} pl-14 mt-0`,
											...aria("phone")
										})]
									}),
									err("phone")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-semibold text-primary",
								children: [
									"Current / Target Class ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-destructive",
										children: "*"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										name: "studentClass",
										defaultValue: "",
										className: fieldClass,
										...aria("studentClass"),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												disabled: true,
												children: "Select class"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Class VII",
												children: "Class VII (7th)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Class VIII",
												children: "Class VIII (8th)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Class IX",
												children: "Class IX (9th)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Class X",
												children: "Class X (10th)"
											})
										]
									}),
									err("studentClass")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-semibold text-primary",
								children: [
									"School Board ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-destructive",
										children: "*"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										name: "board",
										defaultValue: "",
										className: fieldClass,
										...aria("board"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											disabled: true,
											children: "Select board"
										}), boards.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: b }, b))]
									}),
									err("board")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-semibold text-primary sm:col-span-2",
								children: [
									"Program of Interest ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-destructive",
										children: "*"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										name: "program",
										defaultValue: defaultProgram,
										className: fieldClass,
										...aria("program"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											disabled: true,
											children: "Select program"
										}), programs.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: p.name,
											children: [
												p.name,
												" ",
												p.highlight ? `(${p.highlight})` : ""
											]
										}, p.id))]
									}),
									err("program")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-semibold text-primary sm:col-span-2",
								children: ["Specific Query or Notes (Optional)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									name: "notes",
									rows: 2,
									placeholder: "Mention any specific learning requirements or morning batch preference...",
									className: fieldClass
								})]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-4 border-t pt-5 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, { className: "size-4 text-emerald-600 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Enquiry is directly submitted to ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
							" admissions desk."
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: !isVerified || isSubmitting,
						className: "inline-flex items-center justify-center gap-2 rounded-full bg-gold px-8 py-3.5 font-bold text-gold-foreground transition hover:-translate-y-0.5 hover:shadow-card disabled:opacity-50 disabled:cursor-not-allowed",
						children: isSubmitting ? "Submitting Enquiry..." : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Submit Official Enquiry ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })] })
					})]
				})]
			})
		]
	});
}
function ContactSection({ title }) {
	const displayTitle = title ?? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		"Begin your ",
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
		" journey"
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "enquire",
		className: "scroll-mt-24 bg-secondary py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-ace grid gap-10 lg:grid-cols-[1fr_1.4fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Eyebrow, { children: ["Admission enquiry · ", contact.admissionYear] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 text-3xl font-semibold text-primary md:text-4xl",
					children: displayTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted-foreground",
					children: "Share a few details, or reach us directly. We teach Classes VII, VIII, IX & X across ICSE, CBSE and State Board."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: contact.whatsappHref,
							target: "_blank",
							rel: "noreferrer",
							className: "flex items-center gap-4 rounded-2xl bg-card p-4 shadow-card transition hover:shadow-lift",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 place-items-center rounded-xl bg-emerald-600 text-white",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "size-5",
									"aria-hidden": true
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "WhatsApp Admissions Desk"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-primary",
								children: contact.phoneDisplay
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: contact.phoneHref,
							className: "flex items-center gap-4 rounded-2xl bg-card p-4 shadow-card transition hover:shadow-lift",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 place-items-center rounded-xl bg-gold text-gold-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "size-5",
									"aria-hidden": true
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "Direct Call"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-primary",
								children: contact.phoneDisplay
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: contact.mapsHref,
							target: "_blank",
							rel: "noreferrer",
							className: "flex items-center gap-4 rounded-2xl bg-card p-4 shadow-card transition hover:shadow-lift",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
									className: "size-5",
									"aria-hidden": true
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-semibold text-primary",
								children: contact.addressLines.join(" ")
							})]
						})
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnquiryForm, {})]
		})
	});
}
//#endregion
export { LogoFallback as a, SafeImage as c, boards as d, cn as f, Faq as i, SectionHeading as l, programs as m, AchieverCard as n, Placeholder as o, contact as p, ContactSection as r, ProgramCard as s, AceWord as t, achieverGroups as u };
