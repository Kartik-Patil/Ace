import { i as __toESM } from "../_runtime.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { A as ClipboardCheck, C as Languages, F as Calculator, L as BookOpenCheck, R as ArrowRight, S as Layers, i as TrendingUp, k as Compass, l as RotateCw, o as Sparkles, p as Play, u as Rocket } from "../_libs/lucide-react.mjs";
import { d as boards, l as SectionHeading, p as contact, r as ContactSection, t as AceWord } from "./ContactSection-BXmyUUuK.mjs";
import { t as Reveal } from "./Reveal-CXClgHMJ.mjs";
import { t as programs_illustration_default } from "./programs-illustration-j7FCCwlT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses-Bzw2G1j0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AcesetSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-secondary/40 py-24 border-y border-border overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-ace",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					variant: "fade-up",
					className: "text-center max-w-3xl mx-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-bold uppercase tracking-[0.2em] text-sky-border mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}), "SET – Scholarship Entrance Test"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-extrabold tracking-tight text-primary sm:text-4xl lg:text-5xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "relative inline-block",
								children: [
									"Why participate in",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "italic text-gold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}), "SET?"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										className: "absolute -bottom-2.5 left-0 w-full h-3.5 text-gold overflow-visible",
										viewBox: "0 0 320 12",
										fill: "none",
										preserveAspectRatio: "none",
										"aria-hidden": true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: "M3 8.5C65 2.5 190 2 317 7.5",
											stroke: "currentColor",
											strokeWidth: "4.5",
											strokeLinecap: "round"
										})
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-base sm:text-lg text-muted-foreground font-medium",
							children: "Your Potential Deserves an Opportunity to Excel! Discover your strengths, earn merit scholarships and chart your academic roadmap."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-14 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-7 flex flex-col gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							variant: "fade-up",
							delay: 0,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group relative overflow-hidden rounded-3xl bg-navy-pattern p-7 sm:p-8 text-navy-foreground border-2 border-gold/40 shadow-lift transition duration-300",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -top-16 -right-16 size-56 rounded-full bg-gold/15 blur-3xl" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -bottom-16 -left-16 size-48 rounded-full bg-sky-border/20 blur-2xl" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 md:grid-cols-12 gap-6 items-center relative z-10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "md:col-span-6",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1.5 rounded-full bg-gold px-3.5 py-1 text-xs font-bold uppercase tracking-wider text-gold-foreground shadow-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3" }), " Up to 100% Scholarship*"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
													className: "mt-3 font-display text-2xl sm:text-3xl font-bold leading-tight",
													children: ["Unlock ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "italic text-gold",
														children: "Scholarship Opportunities"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-3 text-sm leading-relaxed opacity-90",
													children: "Get an opportunity to earn merit scholarships of up to 100%* and make quality education and academic foundation more accessible."
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "md:col-span-6 flex justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "w-full max-w-sm rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 p-4 shadow-xl transition-transform duration-300 group-hover:scale-[1.02]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between pb-3 border-b border-white/15 text-xs font-medium text-white/80",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1.5",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-rose-400" }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-amber-400" }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-emerald-400" }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "ml-2 font-semibold text-gold",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }), "SET Merit Tiers"]
															})
														]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] uppercase tracking-wider bg-white/10 px-2 py-0.5 rounded text-white/70",
														children: "2027–28"
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-3 space-y-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between rounded-xl bg-gold/20 border border-gold/40 px-3 py-2 text-xs",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-bold text-gold flex items-center gap-1.5",
																children: "🏆 Tier 1 Distinction"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-mono font-extrabold text-gold bg-gold/20 px-2 py-0.5 rounded",
																children: "100% Fee Waiver"
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between rounded-xl bg-white/15 px-3 py-2 text-xs",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-semibold text-sky-200 flex items-center gap-1.5",
																children: "🥇 90th+ Percentile"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-mono font-bold text-white",
																children: "75% Scholarship"
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between rounded-xl bg-white/15 px-3 py-2 text-xs",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-semibold text-emerald-200 flex items-center gap-1.5",
																children: "🥈 Merit Achievers"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-mono font-bold text-white",
																children: "50% Scholarship"
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between rounded-xl bg-white/15 px-3 py-2 text-xs",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-semibold text-purple-200 flex items-center gap-1.5",
																children: "🥉 Foundation Grant"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-medium text-white/90",
																children: "25% Support"
															})]
														})
													]
												})]
											})
										})]
									})
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-6 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								variant: "fade-up",
								delay: 80,
								className: "h-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group h-full flex flex-col justify-between rounded-3xl border-2 border-sky-border/40 bg-card p-6 sm:p-7 shadow-card hover:shadow-lift transition duration-300 hover:border-sky-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "inline-block rounded-full bg-sky px-3 py-1 text-xs font-bold uppercase tracking-wider text-primary border border-sky-border/30",
											children: "Diagnostic Benchmark"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-4 font-display text-xl sm:text-2xl font-bold text-primary",
											children: "Academic Readiness"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed text-muted-foreground",
											children: "Understand your current level of preparation and assess your strengths across key subjects."
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 rounded-2xl bg-gradient-to-b from-sky/60 to-sky/20 border border-sky-border/30 p-4 transition-transform duration-300 group-hover:scale-[1.02]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between border-b border-sky-border/40 pb-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex items-center gap-1.5",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-bold text-primary",
														children: "Subject Competence Radar"
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200",
													children: "Detailed Report"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 space-y-2 text-xs",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between font-semibold text-foreground text-[11px] mb-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mathematics & Logic" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-mono text-primary font-bold",
															children: "96%"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "h-1.5 w-full rounded-full bg-slate-200 overflow-hidden",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-[96%] rounded-full bg-gold" })
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between font-semibold text-foreground text-[11px] mb-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Physics & Chemistry" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-mono text-primary font-bold",
															children: "91%"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "h-1.5 w-full rounded-full bg-slate-200 overflow-hidden",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-[91%] rounded-full bg-sky-border" })
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between font-semibold text-foreground text-[11px] mb-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Biology & Aptitude" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-mono text-primary font-bold",
															children: "94%"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "h-1.5 w-full rounded-full bg-slate-200 overflow-hidden",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-[94%] rounded-full bg-emerald-500" })
													})] })
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 pt-2 border-t border-sky-border/20 text-[11px] text-muted-foreground flex justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Personalized Diagnostic Analysis" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-primary",
													children: "Included"
												})]
											})
										]
									})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								variant: "fade-up",
								delay: 160,
								className: "h-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group h-full flex flex-col justify-between rounded-3xl bg-primary text-primary-foreground border-2 border-gold/40 p-6 sm:p-7 shadow-card hover:shadow-lift transition duration-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "inline-block rounded-full bg-gold/20 text-gold border border-gold/40 px-3 py-1 text-xs font-bold uppercase tracking-wider",
											children: "Customized Roadmap"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "mt-4 font-display text-xl sm:text-2xl font-bold leading-tight",
											children: ["Discover Your ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "italic text-gold",
												children: "Pathway"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed opacity-90",
											children: "Explore the right academic programme based on your individual strengths, interests and future aspirations."
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 relative h-48 flex items-center justify-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "absolute w-[86%] rounded-2xl bg-white/15 border border-white/20 p-3.5 rotate-6 shadow-md transition-transform duration-300 group-hover:rotate-8",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-[11px] text-white/80",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Olympiad & NTSE Track" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono text-gold",
													children: "Class 9"
												})]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative w-[92%] rounded-2xl bg-gold text-gold-foreground p-4 -rotate-3 shadow-xl border border-white/40 transition-transform duration-300 group-hover:-rotate-1 group-hover:scale-105",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "grid size-6 place-items-center rounded-lg bg-primary text-gold",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-3.5" })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs font-bold tracking-tight",
															children: "STEM Foundation Roadmap"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-extrabold uppercase tracking-wider bg-primary/10 px-2 py-0.5 rounded-full",
														children: "Class 8-10"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-2.5 text-xs font-semibold leading-snug",
													children: "School Curriculum $\\rightarrow$ Analytical Logic $\\rightarrow$ Competitive JEE / NEET Readiness"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-3 flex items-center justify-between text-[10px] font-bold border-t border-primary/20 pt-2 opacity-90",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1-on-1 Academic Counseling" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-primary font-mono",
														children: "Guaranteed"
													})]
												})
											]
										})]
									})]
								})
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-5 flex flex-col gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							variant: "fade-up",
							delay: 120,
							className: "flex-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group h-full flex flex-col justify-between rounded-3xl border-2 border-sky-border/40 bg-card p-6 sm:p-7 shadow-card hover:shadow-lift transition duration-300 hover:border-sky-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative rounded-2xl bg-gradient-to-b from-sky/40 via-sky/20 to-transparent p-4 pb-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute top-2 right-2 rounded-full bg-primary text-primary-foreground px-2.5 py-1 text-[10px] font-bold flex items-center gap-1 shadow-md",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "size-2.5 text-gold" }), " Student-Centric Pedagogy"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mx-auto w-full max-w-[280px] rounded-t-xl bg-slate-900 p-2 shadow-2xl border-2 border-slate-700",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative aspect-video rounded-lg bg-navy flex flex-col justify-between p-3 overflow-hidden",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between text-[10px] text-white/70",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-bold text-gold",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }), "SET Concept-First Demo"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "bg-emerald-500/80 text-white px-1.5 py-0.2 rounded font-mono text-[9px]",
															children: "ACTIVE"
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "self-center my-auto grid size-10 place-items-center rounded-full bg-gold text-gold-foreground shadow-lg transition-transform duration-300 group-hover:scale-110 cursor-pointer",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current ml-0.5" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "space-y-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex justify-between text-[9px] text-white/80",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Interactive Teaching Methodology" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-mono text-gold",
																children: "100% Practical"
															})]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "h-1 w-full rounded-full bg-white/20 overflow-hidden",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-4/5 rounded-full bg-gold" })
														})]
													})
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mx-auto h-2.5 w-full max-w-[310px] rounded-b-lg bg-slate-400/80 shadow-md flex justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 w-12 rounded-full bg-slate-600/40 mt-0.5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 flex items-center justify-center gap-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-sky border border-sky-border/40 px-3 py-1 text-[11px] font-bold text-primary shadow-xs",
												children: "✨ Concept Clarity · Problem-Solving · Mentorship"
											})
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "inline-block rounded-full bg-primary/10 text-primary border border-primary/20 px-3 py-1 text-xs font-bold uppercase tracking-wider",
											children: "Pedagogy & Mentoring"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "mt-3 font-display text-2xl font-bold text-primary",
											children: [
												"The ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
												" Learning Approach"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-2 text-sm leading-relaxed text-muted-foreground",
											children: [
												"Get introduced to ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
												"'s student-centric teaching methodology, concept-based learning and individual academic mentoring."
											]
										})
									]
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							variant: "fade-up",
							delay: 200,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "group rounded-3xl border-2 border-sky-border/50 bg-sky/70 p-6 sm:p-7 shadow-card hover:shadow-lift transition duration-300 hover:border-sky-border",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-12 gap-5 items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "sm:col-span-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "inline-block rounded-full bg-gold px-3 py-1 text-xs font-bold uppercase tracking-wider text-gold-foreground",
												children: "Excellence Roadmap"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-3 font-display text-xl sm:text-2xl font-bold text-primary",
												children: "Take the First Step"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-2 text-sm leading-relaxed text-muted-foreground",
												children: [
													"Begin your journey towards stronger concepts, sharper thinking and greater confidence with ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
													" Foundation Programmes."
												]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "sm:col-span-6 flex justify-center sm:justify-end",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative w-full max-w-[220px] rounded-2xl bg-white p-3.5 shadow-lift border border-sky-border/40 transition-transform duration-300 group-hover:scale-105",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1.5 w-full rounded-full bg-gold mb-3" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "absolute top-2 right-2 size-12 rounded-full border-2 border-dashed border-emerald-600 bg-emerald-50/90 text-emerald-700 grid place-items-center -rotate-12 shadow-sm pointer-events-none",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "text-center leading-none",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "block text-[8px] font-black uppercase tracking-tighter",
															children: "QUALIFIED"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "block text-[7px] font-bold uppercase tracking-widest text-emerald-600",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}), "SET"]
														})]
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[11px] font-bold text-primary",
													children: "Registration Pass"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[10px] text-muted-foreground",
													children: "Class 8 · 9 · 10 Foundation"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-2 space-y-1 text-[10px] font-medium text-foreground",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1.5",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-emerald-600 font-bold",
																children: "✓"
															}),
															" Seat Preference: ",
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-bold text-primary ml-auto",
																children: "Reserved"
															})
														]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1.5",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-emerald-600 font-bold",
																children: "✓"
															}),
															" Syllabus Guide: ",
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-bold text-primary ml-auto",
																children: "Dispatched"
															})
														]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-3 pt-2 border-t border-border",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "text-center text-[9px] font-bold text-emerald-700 flex items-center justify-center gap-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3" }), " +100% Prepared For Board & STEM"]
													})
												})
											]
										})
									})]
								})
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-center text-xs text-muted-foreground",
					children: "*Scholarship percentage is subject to eligibility criteria, test score benchmark and batch availability."
				})
			]
		})
	});
}
/**
* Realistic 3D Gold Pushpin
* Simulates a physical pin sticking the card to a notice board.
*/
function PushPin({ className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `relative flex items-center justify-center ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-4 left-1/2 -translate-x-1/2 w-6 h-2 rounded-full bg-slate-900/30 blur-[2px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: "34",
			height: "38",
			viewBox: "0 0 32 36",
			fill: "none",
			xmlns: "http://www.w3.org/2000/svg",
			className: "relative z-10 filter drop-shadow-md",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M16 26L16 35",
					stroke: "#334155",
					strokeWidth: "2.5",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "16",
					cy: "25",
					rx: "4.5",
					ry: "2",
					fill: "#94a3b8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M12 17C12 21 13.5 24 16 24C18.5 24 20 21 20 17H12Z",
					fill: "#b45309"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "16",
					cy: "13",
					r: "10",
					fill: "url(#goldPinGrad)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "13.5",
					cy: "9.5",
					rx: "4",
					ry: "2.5",
					fill: "#fef08a",
					opacity: "0.85"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "14",
					cy: "9",
					r: "1.5",
					fill: "#ffffff"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
					id: "goldPinGrad",
					cx: "35%",
					cy: "30%",
					r: "70%",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "#fde047"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "45%",
							stopColor: "#f59e0b"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "85%",
							stopColor: "#d97706"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "#92400e"
						})
					]
				}) })
			]
		})]
	});
}
function ProgrammesSplashSection() {
	const [flippedCards, setFlippedCards] = (0, import_react.useState)({});
	const [hoveredCard, setHoveredCard] = (0, import_react.useState)(null);
	const toggleFlip = (id) => {
		setFlippedCards((prev) => ({
			...prev,
			[id]: !prev[id]
		}));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "what-we-offer",
		className: "relative overflow-hidden bg-secondary/50 py-24 border-y border-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(#1b365d_1px,transparent_1px)] [background-size:24px_24px] opacity-[0.04]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -top-24 -left-24 size-96 rounded-full bg-gold/10 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -bottom-24 right-0 size-96 rounded-full bg-sky-border/20 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						variant: "fade-up",
						className: "text-center max-w-3xl mx-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-[0.2em] text-sky-border mb-3",
								children: "Academic Notice Board · What we offer"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-3xl font-extrabold tracking-tight text-primary sm:text-4xl lg:text-5xl",
								children: [
									"Six programmes,",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "relative inline-block",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "italic text-gold",
											children: "one goal"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
											className: "absolute -bottom-2.5 left-0 w-full h-3.5 text-gold overflow-visible",
											viewBox: "0 0 320 12",
											fill: "none",
											preserveAspectRatio: "none",
											"aria-hidden": "true",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
												d: "M3 8.5C65 2.5 190 2 317 7.5",
												stroke: "currentColor",
												strokeWidth: "4.5",
												strokeLinecap: "round"
											})
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-base sm:text-lg text-muted-foreground font-medium",
								children: "Each card is pinned to our notice board with real student study snapshots. Hover or tap any card to flip it and inspect the comprehensive curriculum table."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3 items-stretch",
						children: [
							{
								id: "bridge",
								num: "01",
								name: "Bridge Course",
								tagline: "Concept Gap Bridging",
								image: "/images/programs/bridge-course.jpg",
								photoCaption: "Geometry compass & concept bridging desk",
								icon: Layers,
								tiltClass: "-rotate-1",
								tableData: [
									{
										label: "Eligible Classes",
										value: "Classes 8, 9 & 10"
									},
									{
										label: "Core Objective",
										value: "Identify & bridge concept curriculum gaps"
									},
									{
										label: "Subjects Covered",
										value: "Physics, Chemistry, Mathematics"
									},
									{
										label: "Teaching Method",
										value: "Diagnostic analysis + concept reinforcement"
									},
									{
										label: "Key Outcome",
										value: "100% academic readiness before new school term"
									}
								]
							},
							{
								id: "foundation",
								num: "02",
								name: "Foundation Programme",
								tagline: "STEM & Reasoning Excellence",
								image: "/images/programs/foundation-programme.jpg",
								photoCaption: "Prism spectrum & Snell's law physics bench",
								icon: Rocket,
								tiltClass: "rotate-1.5",
								tableData: [
									{
										label: "Eligible Classes",
										value: "Classes 8, 9 & 10 (3-Year Track)"
									},
									{
										label: "Curriculum Scope",
										value: "PCMB & Analytical Logical Reasoning"
									},
									{
										label: "Aptitude Building",
										value: "Olympiad & competitive problem solving"
									},
									{
										label: "Long-Term Aim",
										value: "Springboard for IIT-JEE, NEET & Pure Sciences"
									},
									{
										label: "Key Outcome",
										value: "Deep fundamental understanding over rote memory"
									}
								]
							},
							{
								id: "board",
								num: "03",
								name: "Board Support",
								tagline: "ICSE · CBSE · State Board",
								image: "/images/programs/board-support.jpg",
								photoCaption: "NCERT book stack & revision study notes",
								icon: BookOpenCheck,
								tiltClass: "-rotate-0.5",
								tableData: [
									{
										label: "Supported Boards",
										value: "ICSE, CBSE & Karnataka State Board"
									},
									{
										label: "Syllabus Coverage",
										value: "100% NCERT & Board syllabus completed early"
									},
									{
										label: "Assessment Pattern",
										value: "Chapter-wise drills & Pre-Board simulated mocks"
									},
									{
										label: "Exam Technique",
										value: "Step-marking mastery & model answer writing"
									},
									{
										label: "Track Record",
										value: "Proven 100% Pass & High Distinction rate"
									}
								]
							},
							{
								id: "tests",
								num: "04",
								name: "Curated Test Series",
								tagline: "Diagnostic & Remedial Assessments",
								image: "/images/programs/curated-tests.jpg",
								photoCaption: "Graded 96/100 test sheet & stopwatch",
								icon: ClipboardCheck,
								tiltClass: "rotate-1",
								tableData: [
									{
										label: "Target Students",
										value: "Classes 8, 9 & 10 (All Boards)"
									},
									{
										label: "Frequency",
										value: "Weekly chapter tests + monthly cumulative mocks"
									},
									{
										label: "Diagnostic Report",
										value: "Granular error mapping & weak topic flagging"
									},
									{
										label: "Faculty Mentorship",
										value: "1-on-1 remedial doubt-solving sessions"
									},
									{
										label: "Key Outcome",
										value: "Assess · Analyse · Improve · Excel"
									}
								]
							},
							{
								id: "math",
								num: "05",
								name: "Math Mastery",
								tagline: "Deep Conceptual Learning",
								image: "/images/programs/math-mastery.jpg",
								photoCaption: "7:00 AM golden morning calculus & hot chai",
								icon: Calculator,
								tiltClass: "-rotate-1.5",
								tableData: [
									{
										label: "Session Timings",
										value: "Early Morning Classes (7:00 AM – 8:30 AM)"
									},
									{
										label: "Learning Atmosphere",
										value: "Fresh morning mind, zero daily distractions"
									},
									{
										label: "Pedagogical Focus",
										value: "First-principles derivations & speed calculation"
									},
									{
										label: "Core Philosophy",
										value: "Eliminates math phobia through structured intuition"
									},
									{
										label: "Key Outcome",
										value: "Transforms Math into student's highest-scoring subject"
									}
								]
							},
							{
								id: "language",
								num: "06",
								name: "Language Support",
								tagline: "Kannada & Hindi Enrichment",
								image: "/images/programs/language-support.jpg",
								photoCaption: "ಕನ್ನಡ & हिन्दी ink calligraphy & Bendre poetry",
								icon: Languages,
								tiltClass: "rotate-0.5",
								tableData: [
									{
										label: "Languages Offered",
										value: "ಕನ್ನಡ (Kannada) & हिन्दी (Hindi)"
									},
									{
										label: "Curriculum Focus",
										value: "Grammar (ವ್ಯಾಕರಣ/व्याकरण), Comprehension & Essays"
									},
									{
										label: "Teaching Mode",
										value: "Native language educators with board specialization"
									},
									{
										label: "Strategic Value",
										value: "Strengthens total board exam percentage"
									},
									{
										label: "Key Outcome",
										value: "Confident linguistic expression & high exam scores"
									}
								]
							}
						].map((p, i) => {
							const Icon = p.icon;
							const isFlipped = Boolean(flippedCards[p.id] || hoveredCard === p.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								variant: "fade-up",
								delay: i * 70,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `group relative h-[450px] sm:h-[470px] cursor-pointer [perspective:1200px] transition-transform duration-300 ${isFlipped ? "rotate-0 scale-[1.02]" : p.tiltClass} hover:rotate-0 hover:scale-[1.02]`,
									onClick: () => toggleFlip(p.id),
									onMouseEnter: () => setHoveredCard(p.id),
									onMouseLeave: () => setHoveredCard(null),
									role: "button",
									tabIndex: 0,
									onKeyDown: (e) => {
										if (e.key === "Enter" || e.key === " ") {
											e.preventDefault();
											toggleFlip(p.id);
										}
									},
									"aria-label": `${p.name} - Tap to toggle curriculum table`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute -top-4 left-1/2 -translate-x-1/2 z-30 pointer-events-none",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PushPin, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `relative size-full transition-transform duration-700 ease-out [transform-style:preserve-3d] ${isFlipped ? "[transform:rotateY(180deg)]" : ""}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute inset-0 size-full [backface-visibility:hidden] rounded-2xl border-2 border-gold/40 bg-card p-6 sm:p-7 shadow-lift flex flex-col justify-between items-center text-center select-none",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-2 rounded-full bg-slate-900/40 shadow-inner mt-0.5" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1 mt-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "inline-flex items-center gap-1.5 rounded-full bg-sky px-2.5 py-0.5 text-[10px] font-bold text-sky-border uppercase tracking-wider",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3 text-gold" }),
																"Programme ",
																p.num
															]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
															className: "font-display text-xl sm:text-2xl font-extrabold tracking-tight text-primary leading-tight",
															children: p.id === "foundation" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
																" ",
																p.name
															] }) : p.name
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] font-semibold text-muted-foreground",
															children: p.tagline
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative my-2 w-full max-w-[250px] mx-auto",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-2 left-1/2 -translate-x-1/2 z-20 w-14 h-3.5 bg-amber-100/90 border border-amber-300/50 shadow-2xs -rotate-2 backdrop-blur-xs pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded-xl bg-white p-2 pb-2.5 shadow-md border border-slate-200/90 transition-transform duration-300 group-hover:scale-[1.02] -rotate-0.5 group-hover:rotate-0",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "relative aspect-[16/11] w-full overflow-hidden rounded-lg bg-slate-100",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
																src: p.image,
																alt: p.name,
																className: "size-full object-cover transition-transform duration-500 group-hover:scale-105",
																loading: "lazy"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-black/5" })]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "mt-1.5 text-[10px] font-bold text-center text-slate-600 font-mono tracking-tight truncate px-1",
															children: p.photoCaption
														})]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "inline-flex items-center gap-1.5 rounded-full border border-gold/40 bg-gold/10 px-4 py-1.5 text-xs font-bold text-primary transition group-hover:bg-gold group-hover:text-gold-foreground",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "size-3.5 animate-spin-slow" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Hover or tap to reveal table" })]
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute inset-0 size-full [backface-visibility:hidden] [transform:rotateY(180deg)] rounded-2xl border-2 border-gold bg-card p-6 sm:p-7 shadow-lift flex flex-col justify-between overflow-y-auto",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between pb-3 border-b border-border text-xs font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
														className: "font-display font-bold text-primary text-sm sm:text-base",
														children: p.id === "foundation" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {}),
															" ",
															p.name
														] }) : p.name
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded bg-gold/20 px-2 py-0.5 text-[10px] font-mono font-bold text-primary",
													children: "Curriculum Table"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-3 divide-y divide-border/60 text-xs",
												children: p.tableData.map((row, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "py-2.5 flex items-start justify-between gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-primary shrink-0 w-28 text-[11px]",
														children: row.label
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-right text-muted-foreground font-medium text-[11px] leading-tight",
														children: row.value
													})]
												}, idx))
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-4 pt-3 border-t border-border flex items-center justify-between gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: (e) => {
														e.stopPropagation();
														toggleFlip(p.id);
													},
													className: "inline-flex items-center gap-1 text-[11px] font-bold text-muted-foreground hover:text-primary transition",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "size-3" }), " Flip back"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: "#enquire",
													onClick: (e) => e.stopPropagation(),
													className: "inline-flex items-center gap-1.5 rounded-full bg-gold px-3.5 py-1.5 text-xs font-bold text-gold-foreground transition hover:shadow-md hover:-translate-y-0.5",
													children: ["Enquire Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3" })]
												})]
											})]
										})]
									})]
								})
							}, p.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						variant: "fade-up",
						delay: 500,
						className: "mt-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-3xl border-2 border-gold/40 bg-navy-pattern p-6 sm:p-8 text-navy-foreground shadow-lift",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col md:flex-row items-center justify-between gap-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1 text-center md:text-left",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "inline-flex items-center gap-2 rounded-full bg-gold/20 px-3 py-1 text-xs font-bold text-gold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5" }), " Flexible Multi-Programme Pathway"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-display text-xl sm:text-2xl font-bold",
											children: "Combine programmes to fit your exact goals"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm opacity-85 max-w-xl",
											children: [
												"Whether bridging a single subject or preparing for both School Boards and competitive exams, ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }),
												" structures your timetable without school clashes."
											]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap items-center justify-center gap-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#enquire",
										className: "rounded-full bg-gold px-6 py-3 text-sm font-bold text-gold-foreground transition hover:-translate-y-0.5 hover:shadow-lg",
										children: "Enquire Now"
									})
								})]
							})
						})
					})
				]
			})
		]
	});
}
function CoursesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "relative overflow-hidden bg-navy-pattern text-navy-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-ace grid items-center gap-10 py-16 md:py-24 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fade-up",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold uppercase tracking-[0.2em] text-gold",
							children: "Programmes for Classes 8, 9 & 10"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-4 text-5xl font-semibold leading-[1.05] md:text-6xl",
							children: [
								"Building Strong Foundations.",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "italic text-gold",
									children: "Preparing for Future Success."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 max-w-xl text-lg opacity-85",
							children: [
								"From closing gaps to building competitive strength, ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }),
								"'s programmes take students from concepts to confidence — for ICSE, CBSE and State Board."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#programmes",
								className: "rounded-full bg-gold px-7 py-3.5 font-bold text-gold-foreground transition hover:-translate-y-0.5",
								children: "View programmes"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#enquire",
								className: "inline-flex items-center gap-2 rounded-full border-2 border-navy-foreground/40 px-7 py-3.5 font-bold hover:border-gold hover:text-gold",
								children: ["Enquire Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "size-4",
									"aria-hidden": true
								})]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: programs_illustration_default,
					alt: "Teacher guiding students through geometry at a whiteboard",
					width: 1280,
					height: 960,
					className: "fade-up rounded-3xl border-4 border-gold/70 shadow-lift [animation-delay:150ms]"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "programmes",
			className: "container-ace scroll-mt-24 py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				variant: "fade-up",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Our programmes",
					title: "Two flagship learning pathways",
					intro: "Structured to strengthen concepts, develop analytical thinking and prepare students for school examinations and beyond."
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid gap-8 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					variant: "slide-left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-full rounded-2xl border-2 border-gold/50 bg-navy-pattern p-8 text-navy-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2 rounded-full bg-gold px-4 py-1.5 text-sm font-bold text-gold-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, {
									className: "size-4",
									"aria-hidden": true
								}), " STEM Foundation Programme"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-5 text-2xl font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }), " Foundation Programme"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm font-semibold uppercase tracking-wide text-gold",
								children: "Year-Long Academic Enrichment · Classes 8, 9 & 10"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 opacity-85",
								children: "A comprehensive three-year academic enrichment programme designed for students who aspire to pursue careers in Engineering, Medicine and Pure Sciences. Focuses on strengthening fundamental concepts, developing scientific aptitude, enhancing analytical and logical reasoning, and nurturing problem-solving abilities."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-xs font-bold uppercase tracking-widest text-gold",
								children: "Covers: PCMB & Reasoning"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					variant: "slide-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-full rounded-2xl border-2 border-sky-border/40 bg-sky p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2 rounded-full bg-primary px-4 py-1.5 text-sm font-bold text-primary-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpenCheck, {
									className: "size-4",
									"aria-hidden": true
								}), " Board Examination Support"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-5 text-2xl font-semibold text-primary",
								children: "Board Prep · Classes 8, 9 & 10"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm font-semibold uppercase tracking-wide text-sky-border",
								children: "ICSE · CBSE · State Board"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-muted-foreground",
								children: "Focused academic guidance, systematic syllabus coverage, concept reinforcement, regular practice and assessments to help students achieve academic excellence in school examinations."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-5 flex flex-wrap gap-3",
								children: boards.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-xl border-2 border-sky-border px-4 py-2 text-sm font-semibold text-primary",
									children: b
								}, b))
							})
						]
					})
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgrammesSplashSection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-ace py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-8 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					variant: "slide-left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-full rounded-2xl border-2 border-sky-border/40 bg-sky p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2 rounded-full bg-primary px-4 py-1.5 text-sm font-bold text-primary-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, {
									className: "size-4",
									"aria-hidden": true
								}), " Language Enrichment"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-5 text-2xl font-semibold text-primary",
								children: "Language Support – Hindi & Kannada"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-muted-foreground",
								children: "Dedicated Hindi and Kannada language support to help students strengthen their language skills, improve comprehension and develop confidence in reading, writing and communication."
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					variant: "slide-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-full rounded-2xl border-2 border-sky-border/40 bg-sky p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2 rounded-full bg-primary px-4 py-1.5 text-sm font-bold text-primary-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, {
									className: "size-4",
									"aria-hidden": true
								}), " Academic Test Series"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-5 text-2xl font-semibold text-primary",
								children: "Test Series – Classes 8, 9 & 10"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-muted-foreground",
								children: "A structured assessment programme designed to evaluate students' understanding, strengthen subject knowledge and improve examination readiness. Regular tests, performance analysis and feedback help students identify learning gaps."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm font-bold italic text-sky-border",
								children: "Assess. Analyse. Improve. Excel."
							})
						]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AcesetSection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-ace py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				variant: "zoom-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-navy-pattern p-10 text-navy-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold uppercase tracking-[0.2em] text-gold",
							children: "Boards supported"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 flex flex-wrap gap-4",
							children: boards.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-xl border-2 border-gold px-6 py-3 font-display text-2xl font-semibold",
								children: b
							}, b))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#enquire",
								className: "rounded-full bg-gold px-7 py-3.5 font-bold text-gold-foreground transition hover:-translate-y-0.5",
								children: "Enquire Now"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/results",
								className: "inline-flex items-center gap-2 rounded-full border-2 border-navy-foreground/40 px-7 py-3.5 font-bold hover:border-gold hover:text-gold",
								children: ["Meet our achievers ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "size-4",
									"aria-hidden": true
								})]
							})]
						})
					]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactSection, { title: `Enquire for ${contact.admissionYear}` })
	] });
}
//#endregion
export { CoursesPage as component };
