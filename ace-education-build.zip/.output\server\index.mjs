globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-27T20:25:33.353Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/about-DV7wLxHB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"25c2-MwBV7qYQnDpCatzgSZC62Fpxxdw\"",
		"mtime": "2026-11-05T16:51:28.714Z",
		"size": 9666,
		"path": "../public/assets/about-DV7wLxHB.js"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"1474-2TaOlOjpp0VxYkyjSedeTWnmukc\"",
		"mtime": "2026-10-27T20:25:33.340Z",
		"size": 5236,
		"path": "../public/favicon.png"
	},
	"/assets/career-CU06TP5n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b1-bcGzKclhvE7/cM4sYux9BaCjH1I\"",
		"mtime": "2026-11-05T16:51:28.714Z",
		"size": 177,
		"path": "../public/assets/career-CU06TP5n.js"
	},
	"/assets/courses-C_p_V1RM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9423-CQp88ZWlyEPClMooJfRLUF8LJG0\"",
		"mtime": "2026-11-05T16:51:28.715Z",
		"size": 37923,
		"path": "../public/assets/courses-C_p_V1RM.js"
	},
	"/assets/contact-CU06TP5n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b1-bcGzKclhvE7/cM4sYux9BaCjH1I\"",
		"mtime": "2026-11-05T16:51:28.714Z",
		"size": 177,
		"path": "../public/assets/contact-CU06TP5n.js"
	},
	"/assets/ExamReadySection-B7BvG-O5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4957-CADS6vhUbaR8/d1a57LbaOEooQ8\"",
		"mtime": "2026-11-05T16:51:28.714Z",
		"size": 18775,
		"path": "../public/assets/ExamReadySection-B7BvG-O5.js"
	},
	"/assets/home-6VT0NFtY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2637-V3Lxa/QJ/o6gKmWCGcMKjPoDxZg\"",
		"mtime": "2026-11-05T16:51:28.716Z",
		"size": 9783,
		"path": "../public/assets/home-6VT0NFtY.js"
	},
	"/assets/play-BdHRiBG3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b3-D9JYr3Fi8YbxUw1hJYuX3E4d8IY\"",
		"mtime": "2026-11-05T16:51:28.716Z",
		"size": 179,
		"path": "../public/assets/play-BdHRiBG3.js"
	},
	"/assets/programs-BEI5yGIp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c9a-voUx8e8PZN1YpDNfWZxrUMxH2oo\"",
		"mtime": "2026-11-05T16:51:28.717Z",
		"size": 15514,
		"path": "../public/assets/programs-BEI5yGIp.js"
	},
	"/assets/programs-illustration-BSZ4ke_8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"42-RogKJLnJRCqCbQtUkwIZPamVxCE\"",
		"mtime": "2026-11-05T16:51:28.717Z",
		"size": 66,
		"path": "../public/assets/programs-illustration-BSZ4ke_8.js"
	},
	"/assets/programs-illustration-DOYnd2P0.jpg": {
		"type": "image/jpeg",
		"etag": "\"2d3cd-Rw13Opx9NTyax9jrHpqAWGD5Cbc\"",
		"mtime": "2026-11-05T16:51:28.718Z",
		"size": 185293,
		"path": "../public/assets/programs-illustration-DOYnd2P0.jpg"
	},
	"/assets/results-Bf2Dw05B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"951-L+n+A3PJlCpu7rScGtx/UWqFA4o\"",
		"mtime": "2026-11-05T16:51:28.718Z",
		"size": 2385,
		"path": "../public/assets/results-Bf2Dw05B.js"
	},
	"/assets/styles-DO7kXwr4.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1f4cf-2D1cI0fkmIQX9uCzoZLWo2jxoeY\"",
		"mtime": "2026-11-05T16:51:28.720Z",
		"size": 128207,
		"path": "../public/assets/styles-DO7kXwr4.css"
	},
	"/images/ace-logo-orig.png": {
		"type": "image/png",
		"etag": "\"1234f-oAQ6kEA3FIDZgXwL3AQdLWpYOpI\"",
		"mtime": "2026-10-27T20:26:42.974Z",
		"size": 74575,
		"path": "../public/images/ace-logo-orig.png"
	},
	"/assets/study-illustration-Bm-oErrO.jpg": {
		"type": "image/jpeg",
		"etag": "\"31e45-LON2F/lBVAnPJGJhgfHzcwF2QnE\"",
		"mtime": "2026-11-05T16:51:28.720Z",
		"size": 204357,
		"path": "../public/assets/study-illustration-Bm-oErrO.jpg"
	},
	"/images/ace-logo.png": {
		"type": "image/png",
		"etag": "\"12606-7+W6CPnpa0cFdMTTyRNXQOsYBCA\"",
		"mtime": "2026-11-01T10:15:03.806Z",
		"size": 75270,
		"path": "../public/images/ace-logo.png"
	},
	"/images/achievers/amogh-mantur.webp": {
		"type": "image/webp",
		"etag": "\"2df0-hwUmxxgj6hwmqP+/ZpaVrRYo300\"",
		"mtime": "2026-10-27T20:26:42.976Z",
		"size": 11760,
		"path": "../public/images/achievers/amogh-mantur.webp"
	},
	"/images/achievers/aadhya-hiremath.webp": {
		"type": "image/webp",
		"etag": "\"32ba-X+CVx95n0qjmNZ+B3AvL310y8ZE\"",
		"mtime": "2026-10-27T20:26:42.975Z",
		"size": 12986,
		"path": "../public/images/achievers/aadhya-hiremath.webp"
	},
	"/images/achievers/khalid-mirji.webp": {
		"type": "image/webp",
		"etag": "\"2ca8-5pdvkJKjvfd3K+Q54EM7JFnp7ZU\"",
		"mtime": "2026-10-27T20:26:42.976Z",
		"size": 11432,
		"path": "../public/images/achievers/khalid-mirji.webp"
	},
	"/images/achievers/prasanna-totad.webp": {
		"type": "image/webp",
		"etag": "\"2d96-nXI/+/5clvJ9bh+hcZRndTYoRXI\"",
		"mtime": "2026-10-27T20:26:42.978Z",
		"size": 11670,
		"path": "../public/images/achievers/prasanna-totad.webp"
	},
	"/images/achievers/mohammad-ayaan.webp": {
		"type": "image/webp",
		"etag": "\"2eb6-lnKc5Nj1znxce6vOBpf9vouyDxU\"",
		"mtime": "2026-10-27T20:26:42.977Z",
		"size": 11958,
		"path": "../public/images/achievers/mohammad-ayaan.webp"
	},
	"/images/achievers/niranjan-k.webp": {
		"type": "image/webp",
		"etag": "\"3668-DwuFwu/ruDPctc6OLhIJMCKp5tg\"",
		"mtime": "2026-10-27T20:26:42.977Z",
		"size": 13928,
		"path": "../public/images/achievers/niranjan-k.webp"
	},
	"/images/achievers/rajat-kulkarni.webp": {
		"type": "image/webp",
		"etag": "\"30aa-ygRmmXXsDUH48ggO3sgatavATjg\"",
		"mtime": "2026-10-27T20:26:42.980Z",
		"size": 12458,
		"path": "../public/images/achievers/rajat-kulkarni.webp"
	},
	"/images/achievers/shalini-shettar.webp": {
		"type": "image/webp",
		"etag": "\"2600-1PZqFBRhn5ZLZdRNMVC1r+KlaXI\"",
		"mtime": "2026-10-27T20:26:42.981Z",
		"size": 9728,
		"path": "../public/images/achievers/shalini-shettar.webp"
	},
	"/images/achievers/sanjana-benakatti.webp": {
		"type": "image/webp",
		"etag": "\"2a64-DUrfE7msW5WTzwsliFS/da5tO60\"",
		"mtime": "2026-10-27T20:26:42.980Z",
		"size": 10852,
		"path": "../public/images/achievers/sanjana-benakatti.webp"
	},
	"/images/achievers/sharan-tugalad.webp": {
		"type": "image/webp",
		"etag": "\"2906-w33iGoZxd50CUDBs5/Fz+FKI8H0\"",
		"mtime": "2026-10-27T20:26:42.981Z",
		"size": 10502,
		"path": "../public/images/achievers/sharan-tugalad.webp"
	},
	"/images/achievers/tejas-onimani.webp": {
		"type": "image/webp",
		"etag": "\"3104-QFh294Lu4zBi/XxLYswSV6RwxPE\"",
		"mtime": "2026-10-27T20:26:42.982Z",
		"size": 12548,
		"path": "../public/images/achievers/tejas-onimani.webp"
	},
	"/images/cards/foundations.jpg": {
		"type": "image/jpeg",
		"etag": "\"7ab65-wmTAhH6HfvmvS4X7GS6GPIARC3I\"",
		"mtime": "2026-11-01T10:36:20.798Z",
		"size": 502629,
		"path": "../public/images/cards/foundations.jpg"
	},
	"/assets/index-DAUwYgrr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90328-DYwHiOWptWUY0TBw57tvPjOZELg\"",
		"mtime": "2026-11-05T16:51:28.713Z",
		"size": 590632,
		"path": "../public/assets/index-DAUwYgrr.js"
	},
	"/images/cards/beyond-classroom.jpg": {
		"type": "image/jpeg",
		"etag": "\"8941b-csawBhiq+qzbNmzhlhIGGifqxXs\"",
		"mtime": "2026-11-01T10:36:41.627Z",
		"size": 562203,
		"path": "../public/images/cards/beyond-classroom.jpg"
	},
	"/images/cards/board-excellence.jpg": {
		"type": "image/jpeg",
		"etag": "\"9176a-l4U7V/xLVmSoAE9z6aX1ebli2ck\"",
		"mtime": "2026-11-01T10:37:31.419Z",
		"size": 595818,
		"path": "../public/images/cards/board-excellence.jpg"
	},
	"/images/cards/essential-skills.jpg": {
		"type": "image/jpeg",
		"etag": "\"94532-mZbKf2Zmd97Zsl2mWMcvTmMDBPc\"",
		"mtime": "2026-11-01T10:37:03.154Z",
		"size": 607538,
		"path": "../public/images/cards/essential-skills.jpg"
	},
	"/images/cards/confidence.jpg": {
		"type": "image/jpeg",
		"etag": "\"83acf-U9m5MhFFCwqzhMKU6u5Nhxgamb0\"",
		"mtime": "2026-11-01T10:37:50.865Z",
		"size": 539343,
		"path": "../public/images/cards/confidence.jpg"
	},
	"/images/programs/curated-tests.jpg": {
		"type": "image/jpeg",
		"etag": "\"cccc8-fAVNR9IHLNqXr9rWHJeCpATWeS0\"",
		"mtime": "2026-11-01T18:04:41.261Z",
		"size": 838856,
		"path": "../public/images/programs/curated-tests.jpg"
	},
	"/images/programs/math-mastery.jpg": {
		"type": "image/jpeg",
		"etag": "\"b517a-HJvg0V8bh5BMVtZQ9E+Bl+MO+Nw\"",
		"mtime": "2026-11-01T18:05:00.970Z",
		"size": 741754,
		"path": "../public/images/programs/math-mastery.jpg"
	},
	"/images/programs/bridge-course.jpg": {
		"type": "image/jpeg",
		"etag": "\"b9b73-GUSURlOaTNNRcknsH9MYX46e4nE\"",
		"mtime": "2026-11-01T18:03:46.276Z",
		"size": 760691,
		"path": "../public/images/programs/bridge-course.jpg"
	},
	"/images/programs/board-support.jpg": {
		"type": "image/jpeg",
		"etag": "\"dd37e-NXF+FBdmgpbGgqyovF+yDOh1/Gc\"",
		"mtime": "2026-11-01T18:04:22.915Z",
		"size": 906110,
		"path": "../public/images/programs/board-support.jpg"
	},
	"/images/programs/foundation-programme.jpg": {
		"type": "image/jpeg",
		"etag": "\"cc62d-pJM8jCfoLLYCaIQ4otOwpkIWEMg\"",
		"mtime": "2026-11-01T18:04:04.236Z",
		"size": 837165,
		"path": "../public/images/programs/foundation-programme.jpg"
	},
	"/images/programs/language-support.jpg": {
		"type": "image/jpeg",
		"etag": "\"cf907-2d6QHe95hsh+xHGxijec+C/zbAs\"",
		"mtime": "2026-11-01T18:05:20.480Z",
		"size": 850183,
		"path": "../public/images/programs/language-support.jpg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_OcuPsB = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_OcuPsB
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
