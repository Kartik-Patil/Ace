import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-Bp2L7blW.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "container-ace py-20 text-center text-muted-foreground" });
}
//#endregion
export { ContactPage as component };
