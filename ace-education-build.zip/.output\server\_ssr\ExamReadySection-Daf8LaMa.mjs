import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { i as TrendingUp, o as Sparkles, p as Play, x as Lightbulb } from "../_libs/lucide-react.mjs";
import { f as cn, t as AceWord } from "./ContactSection-BXmyUUuK.mjs";
import { n as useInView, t as Reveal } from "./Reveal-CXClgHMJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ExamReadySection-Daf8LaMa.js
var import_jsx_runtime = require_jsx_runtime();
/**
* Single rolling digit column.
* Cycles through 0-9 multiple times before settling on target digit,
* creating an authentic mechanical odometer / countdown roll effect.
*/
function DigitColumn({ target, inView, digitIndex, totalDigits, baseDuration = 1600 }) {
	const extraCycles = 2 + digitIndex * .4;
	const fullCycles = Math.floor(extraCycles);
	const sequence = [];
	for (let c = 0; c < fullCycles; c++) for (let d = 0; d <= 9; d++) sequence.push(d);
	for (let d = 0; d <= target; d++) sequence.push(d);
	const targetIndex = sequence.length - 1;
	const duration = baseDuration + digitIndex * 150;
	const delay = digitIndex * 60;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "relative inline-block h-[1.18em] overflow-hidden leading-[1.18em] tabular-nums align-top",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex flex-col will-change-transform",
			style: {
				transform: inView ? `translateY(-${targetIndex / sequence.length * 100}%)` : "translateY(0%)",
				transitionProperty: "transform",
				transitionDuration: `${duration}ms`,
				transitionDelay: `${delay}ms`,
				transitionTimingFunction: "cubic-bezier(0.12, 0.98, 0.24, 1)"
			},
			children: sequence.map((num, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex h-[1.18em] items-center justify-center select-none",
				"aria-hidden": i !== targetIndex,
				children: num
			}, i))
		})
	});
}
/**
* RollingNumber Component
* Splits strings like "500+", "2022", "3", "100%" into individual rolling reels for digits
* and static inline elements for symbols (+, %, etc.), with smooth scroll-triggered roll.
*/
function RollingNumber({ value, className, inView: externalInView, duration = 1600 }) {
	const { ref, inView: internalInView } = useInView({ threshold: .2 });
	const inView = externalInView !== void 0 ? externalInView : internalInView;
	const chars = value.split("");
	const totalDigits = chars.filter((c) => /\d/.test(c)).length;
	let digitCounter = 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		ref,
		className: cn("inline-flex items-baseline justify-center tracking-tight", className),
		"aria-label": value,
		children: chars.map((char, idx) => {
			if (/\d/.test(char)) {
				const digit = parseInt(char, 10);
				const currentDigitIdx = digitCounter++;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DigitColumn, {
					target: digit,
					inView,
					digitIndex: currentDigitIdx,
					totalDigits,
					baseDuration: duration
				}, idx);
			}
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "inline-block transition-all duration-700 select-none",
				style: {
					opacity: inView ? 1 : .4,
					transform: inView ? "scale(1)" : "scale(0.85)",
					transitionDelay: `${duration + 100}ms`
				},
				children: char
			}, idx);
		})
	});
}
function ExamReadySection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-secondary/40 py-24 border-y border-border overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-ace",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				variant: "fade-up",
				className: "text-center max-w-3xl mx-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-3xl font-extrabold tracking-tight text-primary sm:text-4xl lg:text-5xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative inline-block",
							children: ["Everything you need for your Exam", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								className: "absolute -bottom-2.5 left-0 w-full h-3.5 text-gold overflow-visible",
								viewBox: "0 0 320 12",
								fill: "none",
								preserveAspectRatio: "none",
								"aria-hidden": true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M3 8.5C65 2.5 190 2 317 7.5",
									stroke: "currentColor",
									strokeWidth: "4.5",
									strokeLinecap: "round"
								})
							})]
						}),
						" ",
						"at one place"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-base sm:text-lg text-muted-foreground font-medium",
					children: "Designed to help you learn faster, stay confident and be 100% exam ready. A purposeful commitment to every student who walks through our doors."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-14 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 flex flex-col gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						variant: "fade-up",
						delay: 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group relative overflow-hidden rounded-3xl bg-navy-pattern p-7 sm:p-8 text-navy-foreground border-2 border-gold/40 shadow-lift transition duration-300",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -top-16 -right-16 size-56 rounded-full bg-gold/15 blur-3xl" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -bottom-16 -left-16 size-48 rounded-full bg-sky-border/20 blur-2xl" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 md:grid-cols-12 gap-6 items-center relative z-10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "md:col-span-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1.5 rounded-full bg-gold px-3.5 py-1 text-xs font-bold uppercase tracking-wider text-gold-foreground shadow-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3" }), " PCMB Conceptual Mastery"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
												className: "mt-3 font-display text-2xl sm:text-3xl font-bold leading-tight",
												children: ["Build ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "italic text-gold",
													children: "Strong Foundations"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 text-sm leading-relaxed opacity-90",
												children: "Develop conceptual understanding in Physics, Chemistry, Mathematics and Biology to move from rote learning to analytical excellence."
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "md:col-span-6 flex justify-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "w-full max-w-sm rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 p-4 shadow-xl transition-transform duration-300 group-hover:scale-[1.02]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between pb-3 border-b border-white/15 text-xs font-medium text-white/80",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-rose-400" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-amber-400" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-emerald-400" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "ml-2 font-semibold text-gold",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }), " Concept Vault"]
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] uppercase tracking-wider bg-white/10 px-2 py-0.5 rounded text-white/70",
													children: "Class 8 · 9 · 10"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 space-y-2.5",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between rounded-xl bg-white/15 px-3 py-2 text-xs",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-semibold text-sky-200 flex items-center gap-1.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-sky-300" }), " Physics"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-mono font-bold text-white tracking-wide",
															children: "F = m · a \xA0|\xA0 v = d/t"
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between rounded-xl bg-white/15 px-3 py-2 text-xs",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-semibold text-emerald-200 flex items-center gap-1.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-300" }), " Chemistry"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-mono font-bold text-white tracking-wide",
															children: "2H₂ + O₂ → 2H₂O"
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between rounded-xl bg-white/15 px-3 py-2 text-xs",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-semibold text-amber-200 flex items-center gap-1.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-amber-300" }), " Mathematics"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-mono font-bold text-white tracking-wide",
															children: "a² + b² = c²"
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between rounded-xl bg-white/15 px-3 py-2 text-xs",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-semibold text-purple-200 flex items-center gap-1.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-purple-300" }), " Biology"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-medium text-white/90",
															children: "Genetics & Cell Theory"
														})]
													})
												]
											})]
										})
									})]
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-6 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							variant: "fade-up",
							delay: 80,
							className: "h-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group h-full flex flex-col justify-between rounded-3xl border-2 border-sky-border/40 bg-card p-6 sm:p-7 shadow-card hover:shadow-lift transition duration-300 hover:border-sky-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "inline-block rounded-full bg-sky px-3 py-1 text-xs font-bold uppercase tracking-wider text-primary border border-sky-border/30",
										children: "Experiential & Hands-on"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 font-display text-xl sm:text-2xl font-bold text-primary",
										children: "Beyond Classroom Learning"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted-foreground",
										children: "Encourage experiential, activity-based and application-oriented learning through real experiments."
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 rounded-2xl bg-gradient-to-b from-sky/60 to-sky/20 border border-sky-border/30 p-4 transition-transform duration-300 group-hover:scale-[1.02]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between border-b border-sky-border/40 pb-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-base",
													children: "🔬"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-bold text-primary",
													children: "Practical Experiment Log"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200",
												children: "Verified Lab"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
											className: "mt-3 space-y-2 text-xs font-medium text-foreground",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "grid size-4 place-items-center rounded-full bg-emerald-500 text-white text-[10px]",
														children: "✓"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Prism Light Dispersion & Optics" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "grid size-4 place-items-center rounded-full bg-emerald-500 text-white text-[10px]",
														children: "✓"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Acid-Base Titration & pH Indicator" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "grid size-4 place-items-center rounded-full bg-emerald-500 text-white text-[10px]",
														children: "✓"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ohm's Law Electric Circuit Assembly" })]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex items-center justify-between pt-2 border-t border-sky-border/20 text-[11px] text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Hands-on Kit Included" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-primary",
												children: "100% Practical"
											})]
										})
									]
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							variant: "fade-up",
							delay: 160,
							className: "h-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group h-full flex flex-col justify-between rounded-3xl bg-primary text-primary-foreground border-2 border-gold/40 p-6 sm:p-7 shadow-card hover:shadow-lift transition duration-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "inline-block rounded-full bg-gold/20 text-gold border border-gold/40 px-3 py-1 text-xs font-bold uppercase tracking-wider",
										children: "Logic & Critical Thinking"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "mt-4 font-display text-xl sm:text-2xl font-bold leading-tight",
										children: ["Develop ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "italic text-gold",
											children: "Essential Skills"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed opacity-90",
										children: "Flip. Recall. Repeat. Strengthen communication, analytical thinking, and problem-solving abilities."
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 relative h-48 flex items-center justify-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute w-[86%] rounded-2xl bg-white/15 border border-white/20 p-3.5 rotate-6 shadow-md transition-transform duration-300 group-hover:rotate-8",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-[11px] text-white/80",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Card #41 · Speed Math" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono",
												children: "2 + 2 = ?"
											})]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative w-[92%] rounded-2xl bg-gold text-gold-foreground p-4 -rotate-3 shadow-xl border border-white/40 transition-transform duration-300 group-hover:-rotate-1 group-hover:scale-105",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "grid size-6 place-items-center rounded-lg bg-primary text-gold",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "size-3.5" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-bold tracking-tight",
														children: "Logic Puzzle #12"
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-extrabold uppercase tracking-wider bg-primary/10 px-2 py-0.5 rounded-full",
													children: "Analytical"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-3 text-xs font-semibold leading-snug",
												children: "“If Angle A = 60° and Angle B = 30°, what is Angle C in triangle ABC?”"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 flex items-center justify-between text-[10px] font-bold border-t border-primary/20 pt-2 opacity-90",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tap to Reveal Solution" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-primary font-mono",
													children: "Ans: 90°"
												})]
											})
										]
									})]
								})]
							})
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5 flex flex-col gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						variant: "fade-up",
						delay: 120,
						className: "flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group h-full flex flex-col justify-between rounded-3xl border-2 border-sky-border/40 bg-card p-6 sm:p-7 shadow-card hover:shadow-lift transition duration-300 hover:border-sky-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative rounded-2xl bg-gradient-to-b from-sky/40 via-sky/20 to-transparent p-4 pb-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute top-2 right-2 rounded-full bg-primary text-primary-foreground px-2.5 py-1 text-[10px] font-bold flex items-center gap-1 shadow-md",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-2.5 fill-gold text-gold" }), " 100+ Hours Curated"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mx-auto w-full max-w-[280px] rounded-t-xl bg-slate-900 p-2 shadow-2xl border-2 border-slate-700",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative aspect-video rounded-lg bg-navy flex flex-col justify-between p-3 overflow-hidden",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between text-[10px] text-white/70",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-bold text-gold",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, { dark: true }), " Board Masterclass"]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "bg-red-500/80 text-white px-1.5 py-0.2 rounded font-mono text-[9px]",
														children: "LIVE"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "self-center my-auto grid size-10 place-items-center rounded-full bg-gold text-gold-foreground shadow-lg transition-transform duration-300 group-hover:scale-110 cursor-pointer",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current ml-0.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between text-[9px] text-white/80",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Class 10 · Quadratic Equations" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-mono",
															children: "18:45 / 24:00"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "h-1 w-full rounded-full bg-white/20 overflow-hidden",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-3/4 rounded-full bg-gold" })
													})]
												})
											]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mx-auto h-2.5 w-full max-w-[310px] rounded-b-lg bg-slate-400/80 shadow-md flex justify-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 w-12 rounded-full bg-slate-600/40 mt-0.5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 flex items-center justify-center gap-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-sky border border-sky-border/40 px-3 py-1 text-[11px] font-bold text-primary shadow-xs",
											children: "✨ 100% NCERT & State Board Syllabus"
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "inline-block rounded-full bg-primary/10 text-primary border border-primary/20 px-3 py-1 text-xs font-bold uppercase tracking-wider",
										children: "Curriculum & Board Mastery"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-3 font-display text-2xl font-bold text-primary",
										children: "Academic Excellence"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted-foreground",
										children: "Provide structured Board Support and Foundation training for Classes 8, 9 & 10 to systematically elevate academic performance in school examinations."
									})
								]
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						variant: "fade-up",
						delay: 200,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "group rounded-3xl border-2 border-sky-border/50 bg-sky/70 p-6 sm:p-7 shadow-card hover:shadow-lift transition duration-300 hover:border-sky-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-12 gap-5 items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "inline-block rounded-full bg-gold px-3 py-1 text-xs font-bold uppercase tracking-wider text-gold-foreground",
											children: "Fear-Free Assessments"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-3 font-display text-xl sm:text-2xl font-bold text-primary",
											children: "Build Confidence"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed text-muted-foreground",
											children: "Help students overcome examination fear through regular assessments, mentoring and personalised guidance."
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "sm:col-span-6 flex justify-center sm:justify-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative w-full max-w-[220px] rounded-2xl bg-white p-3.5 shadow-lift border border-sky-border/40 transition-transform duration-300 group-hover:scale-105",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1.5 w-full rounded-full bg-gold mb-3" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "absolute top-2 right-2 size-12 rounded-full border-2 border-dashed border-red-600 bg-red-50/90 text-red-600 grid place-items-center -rotate-12 shadow-sm pointer-events-none",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-center leading-none",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "block text-sm font-black tracking-tighter",
														children: "A+"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "block text-[8px] font-bold uppercase tracking-widest text-primary",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AceWord, {})
													})]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] font-bold text-primary",
												children: "Assessment Insights"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-muted-foreground",
												children: "Class 10 Board Mock #03"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 space-y-1 text-[10px] font-medium text-foreground",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-emerald-600 font-bold",
															children: "✓"
														}),
														" Concept Clarity: ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-primary ml-auto",
															children: "100%"
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-emerald-600 font-bold",
															children: "✓"
														}),
														" Step Marking: ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-primary ml-auto",
															children: "Secured"
														})
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 pt-2 border-t border-border",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-end justify-between gap-2 h-9 px-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "w-1/3 flex flex-col items-center gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[8px] text-muted-foreground",
																children: "72%"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-full bg-slate-200 rounded-t h-4" })]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "w-1/3 flex flex-col items-center gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[8px] text-muted-foreground",
																children: "85%"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-full bg-sky-border/60 rounded-t h-6" })]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "w-1/3 flex flex-col items-center gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[8px] font-bold text-primary",
																children: "98%"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-full bg-gold rounded-t h-8" })]
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-1 text-center text-[9px] font-bold text-emerald-700 flex items-center justify-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3" }), " +26% Growth Across Tests"]
												})]
											})
										]
									})
								})]
							})
						})
					})]
				})]
			})]
		})
	});
}
//#endregion
export { RollingNumber as n, ExamReadySection as t };
